import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Share2,
  Sparkles,
  Copy,
  Check,
  CheckCircle2,
  ExternalLink,
  Search,
  Eye,
  Code2,
  Globe,
  MessageSquare,
  Smartphone,
  Layers,
} from 'lucide-react';
import type { Profile } from '@/src/types/index';
import { storage } from '@/src/lib/storage';

interface SeoWorkspaceProps {
  profile: Profile;
  onProfileChange: (profile: Profile) => void;
  onOpenUpgrade?: () => void;
}

export function SeoWorkspace({
  profile,
  onProfileChange,
}: SeoWorkspaceProps) {
  const [seoTitle, setSeoTitle] = useState(
    profile.seo_title || `${profile.display_name} (@${profile.handle}) | Official Bio`
  );
  const [seoDesc, setSeoDesc] = useState(
    profile.seo_description ||
      `Explore links, content, socials, and projects from ${profile.display_name}. Connect and discover everything in one place.`
  );
  const [ogImageUrl, setOgImageUrl] = useState(
    profile.banner_url ||
      'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80'
  );
  const [activePreview, setActivePreview] = useState<'google' | 'twitter' | 'whatsapp'>('google');
  const [showCode, setShowCode] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const bioUrl = `https://pagelink.to/@${profile.handle}`;

  const OG_PRESETS = [
    {
      label: 'Pastel Gradient',
      url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
    },
    {
      label: 'Tokyo Neon',
      url: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?w=1200&auto=format&fit=crop&q=80',
    },
    {
      label: 'Mountain Fog',
      url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1200&auto=format&fit=crop&q=80',
    },
    {
      label: 'Sunset Ocean',
      url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&auto=format&fit=crop&q=80',
    },
  ];

  const handleCopyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    try {
      confetti({ particleCount: 30, spread: 50, origin: { y: 0.7 } });
    } catch {}
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleSaveSeo = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: Profile = {
      ...profile,
      seo_title: seoTitle.trim(),
      seo_description: seoDesc.trim(),
    };
    onProfileChange(updated);
    storage.saveProfile(updated);
    setSavedSuccess(true);
    try {
      confetti({ particleCount: 60, spread: 70, origin: { y: 0.5 } });
    } catch {}
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  const generatedHtmlSnippet = `<!-- PageLink SEO & Social Card Meta Tags -->
<title>${seoTitle}</title>
<meta name="description" content="${seoDesc}" />
<link rel="canonical" href="${bioUrl}" />

<!-- OpenGraph (Facebook, LinkedIn, Discord, WhatsApp) -->
<meta property="og:type" content="profile" />
<meta property="og:title" content="${seoTitle}" />
<meta property="og:description" content="${seoDesc}" />
<meta property="og:url" content="${bioUrl}" />
<meta property="og:image" content="${ogImageUrl}" />
<meta property="og:site_name" content="PageLink" />

<!-- Twitter / X Card -->
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="${seoTitle}" />
<meta name="twitter:description" content="${seoDesc}" />
<meta name="twitter:image" content="${ogImageUrl}" />`;

  return (
    <div className="flex flex-col gap-6">
      {/* Toast Alert */}
      {savedSuccess && (
        <div className="flex items-center gap-2 rounded-2xl bg-emerald-600 px-4 py-3 text-xs font-bold text-white shadow-lg animate-bounce">
          <CheckCircle2 className="size-4" />
          <span>SEO and Social Share metadata saved and published successfully!</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900">
              SEO &amp; Social Share
            </h2>
            <span className="flex items-center gap-1 rounded-full bg-indigo-50 px-2.5 py-0.5 text-[11px] font-bold text-indigo-700 border border-indigo-200">
              <Sparkles className="size-3" /> Indexed &amp; Share Ready
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Customize how your PageLink bio appears on Google Search results, WhatsApp, X (Twitter), Facebook, and LinkedIn.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => handleCopyText(bioUrl, 'bio_url')}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 shadow-2xs hover:bg-slate-50 transition-colors"
          >
            {copiedKey === 'bio_url' ? (
              <>
                <Check className="size-3.5 text-emerald-600" />
                <span className="text-emerald-700">Link Copied!</span>
              </>
            ) : (
              <>
                <Copy className="size-3.5 text-slate-400" />
                <span>Copy Bio Link</span>
              </>
            )}
          </button>

          <a
            href={bioUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 rounded-xl bg-indigo-600 px-3.5 py-2 text-xs font-bold text-white shadow-xs hover:bg-indigo-700 transition-colors"
          >
            <span>Live URL</span>
            <ExternalLink className="size-3.5" />
          </a>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Form Settings (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 mb-1 flex items-center gap-2">
              <Search className="size-4 text-indigo-600" />
              Search Engine &amp; Social Meta Tags
            </h3>
            <p className="text-xs text-slate-500 mb-5">
              Control the exact title, description, and preview image search engines and social apps display.
            </p>

            <form onSubmit={handleSaveSeo} className="space-y-4">
              {/* Meta Title */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700">
                    Page Meta Title
                  </label>
                  <span
                    className={`text-[11px] font-semibold ${
                      seoTitle.length >= 45 && seoTitle.length <= 65
                        ? 'text-emerald-600'
                        : seoTitle.length > 65
                        ? 'text-amber-600'
                        : 'text-slate-400'
                    }`}
                  >
                    {seoTitle.length} / 60 characters
                  </span>
                </div>
                <input
                  type="text"
                  value={seoTitle}
                  onChange={(e) => setSeoTitle(e.target.value)}
                  placeholder="e.g. Creator Name (@handle) | Official Bio"
                  className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-xs font-medium focus:border-indigo-500 focus:outline-none"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Recommended: 50–60 characters. Appears as the clickable headline on Google and social cards.
                </span>
              </div>

              {/* Meta Description */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-700">
                    Meta Description
                  </label>
                  <span
                    className={`text-[11px] font-semibold ${
                      seoDesc.length >= 110 && seoDesc.length <= 160
                        ? 'text-emerald-600'
                        : seoDesc.length > 160
                        ? 'text-amber-600'
                        : 'text-slate-400'
                    }`}
                  >
                    {seoDesc.length} / 160 characters
                  </span>
                </div>
                <textarea
                  rows={3}
                  value={seoDesc}
                  onChange={(e) => setSeoDesc(e.target.value)}
                  placeholder="e.g. Discover tutorials, digital downloads, courses, and social links from..."
                  className="w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-xs font-medium focus:border-indigo-500 focus:outline-none"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Recommended: 120–160 characters. A concise description of your page for search engines.
                </span>
              </div>

              {/* Social Share Preview Card Image */}
              <div>
                <label className="text-xs font-bold text-slate-700 mb-1 block">
                  Social Share Preview Image (OG Image)
                </label>
                <input
                  type="text"
                  value={ogImageUrl}
                  onChange={(e) => setOgImageUrl(e.target.value)}
                  placeholder="Image URL for social preview card"
                  className="w-full rounded-xl border border-slate-200 px-3.5 py-2 text-xs font-medium focus:border-indigo-500 focus:outline-none mb-2"
                />

                {/* Preset Choices */}
                <div>
                  <span className="text-[11px] text-slate-400 block mb-1 font-medium">
                    Or select an aesthetic backdrop:
                  </span>
                  <div className="flex items-center gap-2 overflow-x-auto pb-1">
                    {OG_PRESETS.map((p, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setOgImageUrl(p.url)}
                        className={`group relative shrink-0 overflow-hidden rounded-lg border transition-all ${
                          ogImageUrl === p.url
                            ? 'border-indigo-600 ring-2 ring-indigo-500'
                            : 'border-slate-200 hover:border-indigo-400'
                        }`}
                        title={p.label}
                      >
                        <img src={p.url} alt={p.label} className="h-8 w-16 object-cover" />
                      </button>
                    ))}
                    {profile.banner_url && (
                      <button
                        type="button"
                        onClick={() => setOgImageUrl(profile.banner_url!)}
                        className={`group relative shrink-0 overflow-hidden rounded-lg border px-2 py-1 text-[11px] font-bold transition-all ${
                          ogImageUrl === profile.banner_url
                            ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                            : 'border-slate-200 bg-slate-50 text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        Use Profile Banner
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="rounded-xl bg-indigo-600 px-5 py-2.5 text-xs font-bold text-white shadow-sm hover:bg-indigo-700 transition-all active:scale-95"
                >
                  Save SEO &amp; Social Tags
                </button>
              </div>
            </form>
          </div>

          {/* Code Viewer: View Generated Meta Tags */}
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Code2 className="size-4 text-slate-500" />
                <h4 className="text-xs font-bold text-slate-900">
                  Generated HTML Meta Tags
                </h4>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowCode(!showCode)}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 hover:underline"
                >
                  {showCode ? 'Hide Code' : 'View Code'}
                </button>
                <button
                  type="button"
                  onClick={() => handleCopyText(generatedHtmlSnippet, 'meta_code')}
                  className="flex items-center gap-1 rounded-lg border border-slate-200 px-2 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-50"
                >
                  {copiedKey === 'meta_code' ? (
                    <Check className="size-3 text-emerald-600" />
                  ) : (
                    <Copy className="size-3 text-slate-400" />
                  )}
                  <span>Copy</span>
                </button>
              </div>
            </div>

            {showCode && (
              <pre className="mt-3 overflow-x-auto rounded-xl bg-slate-900 p-3.5 text-[11px] leading-relaxed text-slate-200 font-mono">
                {generatedHtmlSnippet}
              </pre>
            )}
          </div>
        </div>

        {/* Right Column: Live Previews (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Eye className="size-4 text-indigo-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  Live Preview
                </h3>
              </div>

              {/* Preview Platform Tabs */}
              <div className="flex items-center gap-1 rounded-xl border border-slate-200 bg-slate-50 p-1">
                <button
                  type="button"
                  onClick={() => setActivePreview('google')}
                  className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-bold transition-all ${
                    activePreview === 'google'
                      ? 'bg-white text-indigo-600 shadow-2xs'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  <Search className="size-3" />
                  Google
                </button>
                <button
                  type="button"
                  onClick={() => setActivePreview('twitter')}
                  className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-bold transition-all ${
                    activePreview === 'twitter'
                      ? 'bg-white text-indigo-600 shadow-2xs'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  <Share2 className="size-3" />
                  X / Twitter
                </button>
                <button
                  type="button"
                  onClick={() => setActivePreview('whatsapp')}
                  className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-bold transition-all ${
                    activePreview === 'whatsapp'
                      ? 'bg-white text-indigo-600 shadow-2xs'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  <MessageSquare className="size-3" />
                  Chat
                </button>
              </div>
            </div>

            {/* PREVIEW 1: GOOGLE SERP */}
            {activePreview === 'google' && (
              <div className="space-y-3">
                <div className="text-[11px] font-semibold text-slate-400">
                  Simulated Google Mobile &amp; Desktop Search Snippet:
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                  <div className="flex items-center gap-2 mb-1.5">
                    <div className="size-6 rounded-full bg-indigo-600 flex items-center justify-center text-[10px] text-white font-bold">
                      P
                    </div>
                    <div className="truncate">
                      <div className="text-[11px] font-medium text-slate-800">
                        PageLink
                      </div>
                      <div className="text-[10px] text-slate-400 truncate">
                        https://pagelink.to/@{profile.handle}
                      </div>
                    </div>
                  </div>
                  <h4 className="text-base font-semibold text-blue-800 hover:underline cursor-pointer leading-snug">
                    {seoTitle || `${profile.display_name} | Official Bio`}
                  </h4>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed line-clamp-3">
                    {seoDesc ||
                      `Discover links, projects, socials, and creative work by ${profile.display_name}.`}
                  </p>
                </div>
              </div>
            )}

            {/* PREVIEW 2: X / TWITTER LARGE CARD */}
            {activePreview === 'twitter' && (
              <div className="space-y-3">
                <div className="text-[11px] font-semibold text-slate-400">
                  Simulated X / Twitter Large Image Card:
                </div>
                <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                  <img
                    src={ogImageUrl}
                    alt="Social Card Banner"
                    className="h-40 w-full object-cover"
                  />
                  <div className="p-3.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      pagelink.to
                    </span>
                    <h4 className="text-xs font-bold text-slate-900 truncate mt-0.5">
                      {seoTitle}
                    </h4>
                    <p className="text-[11px] text-slate-500 line-clamp-2 mt-0.5 leading-relaxed">
                      {seoDesc}
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* PREVIEW 3: WHATSAPP / IMESSAGE */}
            {activePreview === 'whatsapp' && (
              <div className="space-y-3">
                <div className="text-[11px] font-semibold text-slate-400">
                  Simulated WhatsApp &amp; iMessage Bubble:
                </div>
                <div className="rounded-2xl bg-emerald-50/70 p-3 border border-emerald-100">
                  <div className="max-w-[280px] rounded-xl bg-white border border-slate-200 shadow-xs overflow-hidden">
                    <img
                      src={ogImageUrl}
                      alt="Card"
                      className="h-28 w-full object-cover"
                    />
                    <div className="p-2.5">
                      <div className="text-xs font-bold text-slate-900 truncate">
                        {seoTitle}
                      </div>
                      <div className="text-[10px] text-slate-500 line-clamp-2 mt-0.5">
                        {seoDesc}
                      </div>
                      <div className="text-[9px] font-medium text-slate-400 mt-1">
                        pagelink.to/@{profile.handle}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export { SeoWorkspace as CustomDomainsWorkspace };
