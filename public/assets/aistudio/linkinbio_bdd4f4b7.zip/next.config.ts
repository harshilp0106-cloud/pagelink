import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* Nothing to configure yet. */
};

export default nextConfig;
