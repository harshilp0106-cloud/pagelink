-- A banner across the top of a creator's page, behind the profile photo.
--
-- Same bucket as the avatar, because the storage policies already key on the creator's own
-- id being the first path segment -- a second bucket would mean a second copy of those four
-- policies to keep in step. The file name carries which one it is.

alter table profiles add column if not exists banner_url text;

-- A banner is a wide image where an avatar is a small square, so the bucket's ceiling moves
-- up to suit the larger of the two. The editor still holds an avatar to 2MB on its own.
do $bucket$
begin
  update storage.buckets set file_size_limit = 4194304 where id = 'avatars';
exception when others then
  raise notice 'Set the avatars bucket to 4MB from the dashboard (%).', sqlerrm;
end $bucket$;
