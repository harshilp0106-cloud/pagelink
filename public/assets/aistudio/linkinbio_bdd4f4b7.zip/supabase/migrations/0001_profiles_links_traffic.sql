-- The whole product in one migration: who a creator is, what sits on their page, and what
-- visitors do with it. Split later migrations off this one; nothing has shipped yet, so
-- there is no reason to fragment the starting point.

create extension if not exists citext;

-- ---------------------------------------------------------------------------
-- Handles the product itself needs, so a creator cannot claim a name that
-- would shadow one of the app's own routes. Kept as a table rather than a list
-- in code, because the check has to run inside the database where the unique
-- index is.
-- ---------------------------------------------------------------------------
create table reserved_handles (handle citext primary key);

insert into reserved_handles (handle) values
  ('admin'), ('analytics'), ('api'), ('app'), ('auth'), ('billing'), ('blog'),
  ('contact'), ('dashboard'), ('editor'), ('explore'), ('faq'), ('forgot-password'),
  ('help'), ('home'), ('legal'), ('login'), ('logout'), ('me'), ('new'), ('onboarding'),
  ('pricing'), ('privacy'), ('profile'), ('r'), ('reset-password'), ('root'), ('settings'),
  ('signup'), ('static'), ('support'), ('terms'), ('upgrade'), ('user'), ('www');

-- ---------------------------------------------------------------------------
-- Creators
-- ---------------------------------------------------------------------------
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  handle citext not null unique,
  display_name text not null default '',
  bio text,
  avatar_url text,
  -- A preset name plus whatever the creator overrode, rather than a column per colour.
  -- The presets are code, so adding one later is a deploy and not a migration.
  theme jsonb not null default '{"preset":"midnight"}'::jsonb,
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  -- Three to thirty characters, starting and ending with a letter or digit, so a handle
  -- reads cleanly in a URL and cannot end in a dot that a mail client would swallow.
  constraint profiles_handle_shape
    check (handle ~* '^[a-z0-9][a-z0-9_.-]{1,28}[a-z0-9]$'),
  constraint profiles_theme_is_object check (jsonb_typeof(theme) = 'object')
);

create function touch_updated_at() returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

create trigger profiles_touch before update on profiles
  for each row execute function touch_updated_at();

-- ---------------------------------------------------------------------------
-- Page content
--
-- One table for links, section headers and embeds rather than three, because they share
-- the one thing that matters: their order on the page. Reordering across three tables
-- means reconciling three sequences, and the creator drags them in one list.
-- ---------------------------------------------------------------------------
create type link_kind as enum ('link', 'header', 'embed');

-- A card shows the title and a thumbnail and sends the visitor to the platform; a player
-- plays inline. Instagram only ever gets a card: its own embed script is client-side and
-- unreliable, and an oEmbed thumbnail now needs a Facebook app and token.
create type embed_mode as enum ('card', 'player');

create table links (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles on delete cascade,
  kind link_kind not null default 'link',
  title text not null default '',
  url text,
  icon text,
  platform text,
  external_id text,
  thumbnail_url text,
  embed_mode embed_mode not null default 'card',
  position int not null default 0,
  is_visible boolean not null default true,
  created_at timestamptz not null default now(),
  constraint links_url_required check (kind = 'header' or coalesce(url, '') <> ''),
  constraint links_embed_platform check (kind <> 'embed' or platform is not null)
);

create index links_profile_idx on links (profile_id, position, created_at);

create table socials (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles on delete cascade,
  platform text not null,
  url text not null,
  position int not null default 0,
  unique (profile_id, platform)
);

create index socials_profile_idx on socials (profile_id, position);

-- ---------------------------------------------------------------------------
-- Traffic
--
-- Rows rather than counters, because the order asks for a date range and a counter cannot
-- be sliced by one. Clicks go when their link goes: a creator who deletes a link is not
-- looking for it in next month's report.
-- ---------------------------------------------------------------------------
create table page_views (
  id bigserial primary key,
  profile_id uuid not null references profiles on delete cascade,
  referrer text,
  created_at timestamptz not null default now()
);

create index page_views_profile_idx on page_views (profile_id, created_at desc);

create table link_clicks (
  id bigserial primary key,
  profile_id uuid not null references profiles on delete cascade,
  link_id uuid not null references links on delete cascade,
  referrer text,
  created_at timestamptz not null default now()
);

create index link_clicks_profile_idx on link_clicks (profile_id, created_at desc);
create index link_clicks_link_idx on link_clicks (link_id, created_at desc);

-- ---------------------------------------------------------------------------
-- Row level security
--
-- The public page is read by visitors who are not signed in, so the anon role reads
-- profiles and their content directly -- but only when the creator has published, and only
-- the rows they chose to show. Everything else is owner-only, and nothing anonymous writes
-- through a table: traffic arrives through the functions below.
-- ---------------------------------------------------------------------------
alter table profiles enable row level security;
alter table links enable row level security;
alter table socials enable row level security;
alter table page_views enable row level security;
alter table link_clicks enable row level security;
alter table reserved_handles enable row level security;

create policy profiles_read on profiles
  for select using (is_published or id = auth.uid());
create policy profiles_insert on profiles
  for insert with check (id = auth.uid());
create policy profiles_update on profiles
  for update using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_delete on profiles
  for delete using (id = auth.uid());

create policy links_read on links
  for select using (
    profile_id = auth.uid()
    or (
      is_visible
      and exists (select 1 from profiles p where p.id = links.profile_id and p.is_published)
    )
  );
create policy links_write on links
  for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());

create policy socials_read on socials
  for select using (
    profile_id = auth.uid()
    or exists (select 1 from profiles p where p.id = socials.profile_id and p.is_published)
  );
create policy socials_write on socials
  for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());

create policy page_views_read on page_views for select using (profile_id = auth.uid());
create policy link_clicks_read on link_clicks for select using (profile_id = auth.uid());

-- No policy on reserved_handles at all: it is read by a definer function, and nobody has
-- any business listing it.

-- ---------------------------------------------------------------------------
-- Handles
-- ---------------------------------------------------------------------------
create function handle_is_valid(p_handle citext) returns boolean
  language sql immutable as $fn$
  select p_handle ~* '^[a-z0-9][a-z0-9_.-]{1,28}[a-z0-9]$'
$fn$;

/**
 * Whether a handle can still be claimed.
 *
 * Definer because the signup form asks this before anyone is signed in, and because it has
 * to see the reserved list and every existing profile -- including unpublished ones, which
 * the read policy hides. It answers yes or no and nothing else, so it leaks no more than
 * the eventual 404 would.
 */
create function handle_available(p_handle citext) returns boolean
  language plpgsql security definer set search_path = public as $fn$
begin
  if not handle_is_valid(p_handle) then
    return false;
  end if;
  if exists (select 1 from reserved_handles r where r.handle = p_handle) then
    return false;
  end if;
  return not exists (select 1 from profiles p where p.handle = p_handle);
end $fn$;

/** Creates the signed-in user's profile. Called once, straight after signup. */
create function claim_handle(p_handle citext, p_display_name text default '')
  returns void language plpgsql security definer set search_path = public as $fn$
declare
  v_user uuid := auth.uid();
begin
  if v_user is null then
    raise exception 'not_signed_in';
  end if;
  if exists (select 1 from profiles p where p.id = v_user) then
    raise exception 'profile_exists';
  end if;
  if not handle_available(p_handle) then
    raise exception 'handle_unavailable';
  end if;

  insert into profiles (id, handle, display_name)
  values (v_user, lower(p_handle), left(trim(coalesce(p_display_name, '')), 60));
end $fn$;

/** Moves an existing creator to a new handle. Their old URL stops working, by design. */
create function change_handle(p_handle citext)
  returns void language plpgsql security definer set search_path = public as $fn$
declare
  v_user uuid := auth.uid();
begin
  if v_user is null then
    raise exception 'not_signed_in';
  end if;
  if exists (select 1 from profiles p where p.id = v_user and p.handle = p_handle) then
    return;
  end if;
  if not handle_available(p_handle) then
    raise exception 'handle_unavailable';
  end if;

  update profiles set handle = lower(p_handle) where id = v_user;
end $fn$;

-- ---------------------------------------------------------------------------
-- Ordering
-- ---------------------------------------------------------------------------
/**
 * Writes a whole new order in one statement.
 *
 * The editor sends the ids as they now sit. Doing this row by row from the client would
 * leave the page half-reordered if one request failed, and would fire a request per row on
 * every drag.
 */
create function reorder_links(p_ids uuid[])
  returns void language sql security definer set search_path = public as $fn$
  update links l
     set position = ordered.position
    from (select id, ordinality::int as position
            from unnest(p_ids) with ordinality as t(id, ordinality)) as ordered
   where l.id = ordered.id
     and l.profile_id = auth.uid();
$fn$;

create function reorder_socials(p_ids uuid[])
  returns void language sql security definer set search_path = public as $fn$
  update socials s
     set position = ordered.position
    from (select id, ordinality::int as position
            from unnest(p_ids) with ordinality as t(id, ordinality)) as ordered
   where s.id = ordered.id
     and s.profile_id = auth.uid();
$fn$;

-- ---------------------------------------------------------------------------
-- Traffic
-- ---------------------------------------------------------------------------
/** Records a visit to a published page. Silent about unknown handles. */
create function track_view(p_handle citext, p_referrer text default null)
  returns void language plpgsql security definer set search_path = public as $fn$
declare
  v_creator uuid;
begin
  select p.id into v_creator
    from profiles p where p.handle = p_handle and p.is_published;
  if v_creator is null then
    return;
  end if;
  insert into page_views (profile_id, referrer)
  values (v_creator, nullif(left(coalesce(p_referrer, ''), 300), ''));
end $fn$;

/**
 * Records a click and hands back where the visitor should go.
 *
 * The redirect route asks for the destination rather than being given it, so a link's URL
 * never has to be trusted from the query string -- otherwise the route would happily count
 * a click and forward anyone anywhere.
 */
create function follow_link(p_link uuid, p_referrer text default null)
  returns text language plpgsql security definer set search_path = public as $fn$
declare
  v_url text;
  v_creator uuid;
begin
  select l.url, l.profile_id into v_url, v_creator
    from links l
    join profiles p on p.id = l.profile_id
   where l.id = p_link
     and l.is_visible
     and p.is_published
     and l.kind <> 'header';

  if v_url is null then
    return null;
  end if;

  insert into link_clicks (profile_id, link_id, referrer)
  values (v_creator, p_link, nullif(left(coalesce(p_referrer, ''), 300), ''));

  return v_url;
end $fn$;

/** Views and clicks a day at a time, with the quiet days present rather than missing. */
create function daily_traffic(p_days int default 30)
  returns table (day date, views bigint, clicks bigint)
  language sql security definer set search_path = public as $fn$
  with span as (
    select generate_series(
      (current_date - (greatest(least(p_days, 365), 1) - 1) * interval '1 day')::date,
      current_date,
      interval '1 day'
    )::date as day
  )
  select s.day,
         (select count(*) from page_views v
           where v.profile_id = auth.uid() and v.created_at::date = s.day),
         (select count(*) from link_clicks c
           where c.profile_id = auth.uid() and c.created_at::date = s.day)
    from span s
   order by s.day;
$fn$;

/** Clicks per link over the same window, best first. */
create function link_performance(p_days int default 30)
  returns table (link_id uuid, title text, url text, clicks bigint)
  language sql security definer set search_path = public as $fn$
  select l.id,
         l.title,
         l.url,
         count(c.id)
    from links l
    left join link_clicks c
      on c.link_id = l.id
     and c.created_at >= current_date - (greatest(least(p_days, 365), 1) - 1) * interval '1 day'
   where l.profile_id = auth.uid()
     and l.kind <> 'header'
   group by l.id, l.title, l.url, l.position
   order by count(c.id) desc, l.position;
$fn$;

revoke all on function handle_available(citext) from public;
revoke all on function claim_handle(citext, text) from public;
revoke all on function change_handle(citext) from public;
revoke all on function reorder_links(uuid[]) from public;
revoke all on function reorder_socials(uuid[]) from public;
revoke all on function track_view(citext, text) from public;
revoke all on function follow_link(uuid, text) from public;
revoke all on function daily_traffic(int) from public;
revoke all on function link_performance(int) from public;

grant execute on function handle_available(citext) to anon, authenticated;
grant execute on function track_view(citext, text) to anon, authenticated;
grant execute on function follow_link(uuid, text) to anon, authenticated;
grant execute on function claim_handle(citext, text) to authenticated;
grant execute on function change_handle(citext) to authenticated;
grant execute on function reorder_links(uuid[]) to authenticated;
grant execute on function reorder_socials(uuid[]) to authenticated;
grant execute on function daily_traffic(int) to authenticated;
grant execute on function link_performance(int) to authenticated;

-- ---------------------------------------------------------------------------
-- Avatars
--
-- Public bucket: the images sit on pages meant to be shared, and a signed URL on a public
-- page is a URL that expires while the page is still live. Writes stay owner-only, keyed on
-- the first path segment being the creator's own id.
-- ---------------------------------------------------------------------------
-- Newer Supabase projects refuse writes straight into the storage tables, so this is
-- allowed to fail: on those the bucket is made from the dashboard instead, and the rest of
-- the migration must not be lost because of it.
do $bucket$
begin
  insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
  values ('avatars', 'avatars', true, 2097152,
          array['image/jpeg', 'image/png', 'image/webp'])
  on conflict (id) do nothing;
exception when others then
  raise notice 'Could not create the avatars bucket from SQL (%). Create it from the dashboard: public, 4MB, image/jpeg + image/png + image/webp.', sqlerrm;
end $bucket$;

create policy avatars_read on storage.objects
  for select using (bucket_id = 'avatars');
create policy avatars_insert on storage.objects
  for insert to authenticated with check (
    bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text
  );
create policy avatars_update on storage.objects
  for update to authenticated using (
    bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text
  );
create policy avatars_delete on storage.objects
  for delete to authenticated using (
    bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text
  );
