"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Field, Input } from "@/components/ui";

/**
 * The handle input, with the availability check attached.
 *
 * Asking the database as the creator types is worth the requests: a handle is the one thing
 * on this product that cannot be quietly fixed later, and finding out it was taken after
 * pressing the button means retyping the whole form.
 *
 * The state is derived rather than stored -- an empty box, a badly shaped name and a name
 * the server has already answered for are all knowable during render, so the only thing
 * kept in state is the set of answers. "Checking" is simply a name with no answer yet, and
 * answers are cached for the life of the component, so backspacing over a name already
 * checked costs nothing.
 */
export type HandleState = "empty" | "checking" | "free" | "taken" | "invalid";

const SHAPE = /^[a-z0-9][a-z0-9_.-]{1,28}[a-z0-9]$/;

export function HandleField({
  value,
  onChange,
  onStateChange,
  label = "Your handle",
  currentHandle,
}: {
  value: string;
  onChange: (value: string) => void;
  onStateChange?: (state: HandleState) => void;
  label?: string;
  /** The creator's existing handle, which must count as available to them. */
  currentHandle?: string;
}) {
  const [answers, setAnswers] = useState<Record<string, boolean>>({});

  const handle = value.trim().toLowerCase();

  const settled: HandleState | null = !handle
    ? "empty"
    : currentHandle && handle === currentHandle.toLowerCase()
      ? "free"
      : !SHAPE.test(handle)
        ? "invalid"
        : null;

  const state: HandleState =
    settled ??
    (handle in answers ? (answers[handle] ? "free" : "taken") : "checking");

  useEffect(() => {
    if (settled || handle in answers) return;

    let cancelled = false;
    const timer = setTimeout(async () => {
      const supabase = createClient();
      const { data, error } = await supabase.rpc("handle_available", { p_handle: handle });
      if (cancelled) return;
      // A failed request must not read as "taken": the creator would change a perfectly
      // good name because the network hiccuped.
      setAnswers((current) => ({ ...current, [handle]: error ? true : !!data }));
    }, 400);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [handle, settled, answers]);

  useEffect(() => {
    onStateChange?.(state);
  }, [state, onStateChange]);

  const message: Record<HandleState, string> = {
    empty: "Letters, numbers, dots, dashes and underscores. Three characters or more.",
    checking: "Checking...",
    free: "Available.",
    taken: "That one is taken.",
    invalid: "Three to thirty characters, starting and ending with a letter or number.",
  };

  const bad = state === "taken" || state === "invalid";

  return (
    <Field
      label={label}
      htmlFor="handle"
      hint={bad ? undefined : message[state]}
      error={bad ? message[state] : undefined}
    >
      <div className="flex items-center rounded-lg border border-border bg-surface px-3 focus-within:border-ink-400">
        <span className="shrink-0 text-sm text-ink-400">/@</span>
        <Input
          id="handle"
          value={value}
          autoCapitalize="none"
          autoComplete="off"
          spellCheck={false}
          maxLength={30}
          onChange={(event) =>
            onChange(event.target.value.toLowerCase().replace(/[^a-z0-9_.-]/g, ""))
          }
          className="border-0 bg-transparent px-1 focus:border-0"
        />
      </div>
    </Field>
  );
}
