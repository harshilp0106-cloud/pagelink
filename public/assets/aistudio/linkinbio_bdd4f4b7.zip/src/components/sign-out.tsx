"use client";

import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export function SignOut() {
  const router = useRouter();

  async function signOut() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.refresh();
    router.replace("/login");
  }

  return (
    <button
      type="button"
      onClick={signOut}
      className="rounded-lg px-3 py-2 text-left text-sm text-ink-500 hover:bg-ink-50 hover:text-ink-800"
    >
      Sign out
    </button>
  );
}
