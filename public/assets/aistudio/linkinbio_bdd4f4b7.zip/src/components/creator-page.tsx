import Image from "next/image";
import { cardStyle, themeStyle } from "@/lib/theme";
import { iconForUrl, playerSrc } from "@/lib/links";
import { isIconKey, SocialIcon, type IconKey } from "@/components/social-icon";
import { SharePanel } from "@/components/share-panel";
import { cn } from "@/components/ui";
import type { PageLink, Profile, Social } from "@/lib/types";

/**
 * A creator's page.
 *
 * Rendered by both the live page and the editor's preview, from the same props, because a
 * preview that is built from different markup is a preview that eventually lies. The only
 * difference is `mode`: in the editor nothing is clickable and nothing is counted.
 */
export function CreatorPage({
  profile,
  links,
  socials,
  mode = "live",
  share,
}: {
  profile: Pick<
    Profile,
    "handle" | "display_name" | "bio" | "avatar_url" | "banner_url" | "theme"
  >;
  links: PageLink[];
  socials: Social[];
  mode?: "live" | "preview";
  /** The page's own address and a QR of it. Absent in the editor, where there is nothing
   * to share yet and the panel would cover the preview. */
  share?: { url: string; qr: string };
}) {
  const visible = links.filter((link) => link.is_visible);

  return (
    <div
      className="creator-page relative flex min-h-full w-full flex-col items-center"
      style={themeStyle(profile.theme)}
    >
      {share && <SharePanel url={share.url} qr={share.qr} />}

      {/*
        An element rather than a CSS background: the address comes out of the database, and
        dropping it into url() in a style attribute is the one place a stray quote would be
        more than a broken image.
      */}
      {profile.banner_url && (
        <div className="w-full max-w-lg px-5 pt-6">
          <Image
            src={profile.banner_url}
            alt=""
            width={1200}
            height={480}
            unoptimized
            priority
            /*
             * Held to the width of the page's own column and to a fixed ratio. Run edge to
             * edge instead and a desktop browser stretches it into a letterbox strip with
             * most of the picture cropped away, while the rest of the page stays narrow --
             * the two never look like one design.
             */
            className="aspect-[2/1] w-full rounded-xl object-cover"
          />
        </div>
      )}

      <div
        className={cn(
          "flex w-full max-w-lg flex-col items-center gap-6 px-5 pb-10",
          // The photo rides up over the banner, the way it does on a social profile.
          profile.banner_url ? "-mt-14 pt-0" : "pt-10",
        )}
      >
        <header className="flex flex-col items-center gap-3 text-center">
          {profile.avatar_url ? (
            <Image
              src={profile.avatar_url}
              alt={profile.display_name || profile.handle}
              width={96}
              height={96}
              className="size-24 rounded-full object-cover"
              style={profile.banner_url ? { boxShadow: "0 0 0 4px var(--page-bg)" } : undefined}
              unoptimized
            />
          ) : (
            <div
              className="flex size-24 items-center justify-center rounded-full text-2xl font-semibold"
              style={{
                background: "var(--card-bg)",
                color: "var(--card-fg)",
                ...(profile.banner_url ? { boxShadow: "0 0 0 4px var(--page-bg)" } : {}),
              }}
            >
              {(profile.display_name || profile.handle).slice(0, 1).toUpperCase()}
            </div>
          )}

          <div>
            <h1 className="text-2xl font-semibold">{profile.display_name || profile.handle}</h1>
            <p className="text-[15px] opacity-70">@{profile.handle}</p>
          </div>

          {profile.bio && (
            <p className="max-w-md text-[15px] leading-relaxed opacity-85 whitespace-pre-line">
              {profile.bio}
            </p>
          )}

          {socials.length > 0 && (
            <ul className="flex flex-wrap items-center justify-center gap-4">
              {socials.map((social) => {
                const key: IconKey = isIconKey(social.platform)
                  ? social.platform
                  : iconForUrl(social.url);
                return (
                  <li key={social.id}>
                    {mode === "live" ? (
                      <a
                        href={social.url}
                        target="_blank"
                        rel="noopener noreferrer me"
                        aria-label={social.platform}
                        className="block opacity-80 transition-opacity hover:opacity-100"
                      >
                        <SocialIcon name={key} className="size-8" />
                      </a>
                    ) : (
                      <SocialIcon name={key} className="size-8 opacity-80" />
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </header>

        <div className="flex w-full flex-col gap-3.5">
          {visible.map((link) => (
            <Row key={link.id} link={link} theme={profile.theme} mode={mode} />
          ))}
        </div>

        {visible.length === 0 && (
          <p className="text-sm opacity-60">
            {mode === "preview" ? "Your links will appear here." : "Nothing here yet."}
          </p>
        )}

        <p className="pt-4 text-xs opacity-50">Link in Bio</p>
      </div>
    </div>
  );
}

function Row({
  link,
  theme,
  mode,
}: {
  link: PageLink;
  theme: Profile["theme"];
  mode: "live" | "preview";
}) {
  if (link.kind === "header") {
    return (
      <h2 className="pt-3 text-center text-base font-semibold tracking-wide uppercase opacity-70">
        {link.title}
      </h2>
    );
  }

  if (link.kind === "embed" && link.embed_mode === "player" && link.platform) {
    const src = playerSrc(link.platform, link.external_id ?? "");
    if (src) {
      const tall = link.platform === "spotify";
      return (
        <figure className="flex flex-col gap-1.5">
          <div
            className="overflow-hidden"
            style={{ borderRadius: "var(--card-radius)", background: "var(--card-bg)" }}
          >
            <iframe
              src={src}
              title={link.title || link.platform}
              loading="lazy"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; picture-in-picture"
              allowFullScreen
              className="w-full border-0"
              style={{ height: tall ? 152 : undefined, aspectRatio: tall ? undefined : "16 / 9" }}
            />
          </div>
          {link.title && <figcaption className="px-1 text-xs opacity-70">{link.title}</figcaption>}
        </figure>
      );
    }
  }

  const icon: IconKey = isIconKey(link.icon)
    ? link.icon
    : link.platform && isIconKey(link.platform)
      ? link.platform
      : iconForUrl(link.url ?? "");

  const thumbnail = link.kind === "embed" ? link.thumbnail_url : null;

  const body = (
    <>
      {thumbnail ? (
        <Image
          src={thumbnail}
          alt=""
          width={96}
          height={64}
          unoptimized
          className="h-16 w-24 shrink-0 rounded-lg object-cover"
        />
      ) : (
        /*
         * The mark sits in a tile rather than loose on the card.
         *
         * On its own at icon size it read as a bullet point next to the title; the products a
         * creator compares this to all give the logo its own square. The tile is currentColor
         * at a tenth, so it lifts the mark on a dark card and on a light one without needing
         * a colour per theme.
         */
        <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-current/10">
          <SocialIcon name={icon} className="size-7" />
        </span>
      )}
      <span className="min-w-0 flex-1 truncate text-center text-base font-semibold">
        {link.title}
      </span>
      {/* Balances the tile, so the title stays centred on the card rather than beside it. */}
      <span className="size-10 shrink-0" aria-hidden="true" />
    </>
  );

  const className = "creator-card flex items-center gap-3 px-5 py-4";

  if (mode === "preview") {
    return (
      <div className={className} style={cardStyle(theme)}>
        {body}
      </div>
    );
  }

  return (
    <a
      // Through the redirect route rather than straight out, so the click is counted once,
      // server side, without any script on the page.
      href={`/r/${link.id}`}
      target="_blank"
      rel="noopener noreferrer"
      className={className}
      style={cardStyle(theme)}
    >
      {body}
    </a>
  );
}
