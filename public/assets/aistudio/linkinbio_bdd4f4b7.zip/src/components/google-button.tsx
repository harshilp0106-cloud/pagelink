"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui";

/**
 * Google sign-in.
 *
 * Google never asks for a handle, so a creator who arrives this way lands with an account
 * and no page. The callback sends everyone to the editor and the profile guard bounces them
 * to /onboarding to pick one -- rather than trying to invent a handle from their email,
 * which would hand out names nobody would have chosen.
 */
export function GoogleButton({ label = "Continue with Google" }: { label?: string }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function signIn() {
    setBusy(true);
    setError(null);
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}/auth/callback` },
    });
    if (error) {
      setError(error.message);
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-2">
      <Button type="button" variant="outline" onClick={signIn} disabled={busy}>
        <svg viewBox="0 0 24 24" className="size-4" aria-hidden="true">
          <path
            fill="#4285F4"
            d="M23 12.2c0-.8-.1-1.6-.2-2.3H12v4.4h6.2a5.3 5.3 0 0 1-2.3 3.5v2.9h3.7c2.2-2 3.4-5 3.4-8.5Z"
          />
          <path
            fill="#34A853"
            d="M12 23.5c3 0 5.5-1 7.3-2.7l-3.6-2.8c-1 .7-2.3 1.1-3.7 1.1a6.6 6.6 0 0 1-6.2-4.5H2v3a11.5 11.5 0 0 0 10 6Z"
          />
          <path
            fill="#FBBC05"
            d="M5.8 14.6a6.9 6.9 0 0 1 0-4.4V7.3H2a11.5 11.5 0 0 0 0 10.3l3.8-3Z"
          />
          <path
            fill="#EA4335"
            d="M12 5.4c1.6 0 3.1.6 4.3 1.7l3.2-3.2A11.5 11.5 0 0 0 2 7.3l3.8 3a6.6 6.6 0 0 1 6.2-4.9Z"
          />
        </svg>
        {busy ? "Opening Google..." : label}
      </Button>
      {error && <p className="text-xs text-red-600">{error}</p>}
    </div>
  );
}
