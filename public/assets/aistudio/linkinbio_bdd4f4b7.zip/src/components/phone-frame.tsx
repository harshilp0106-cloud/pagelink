/**
 * The preview shell.
 *
 * A phone rather than a plain box, because the page is a phone page: the link goes in an
 * Instagram bio and almost every visitor arrives on a handset. Showing it at desktop width
 * would flatter layouts that do not survive the real thing.
 */
export function PhoneFrame({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="w-[22rem] max-w-full overflow-hidden rounded-[2rem] border-8 border-ink-900 bg-ink-900 shadow-xl">
        <div className="no-scrollbar h-[38rem] overflow-y-auto overscroll-contain bg-surface">
          {children}
        </div>
      </div>
      <p className="text-xs text-ink-400">Live preview</p>
    </div>
  );
}
