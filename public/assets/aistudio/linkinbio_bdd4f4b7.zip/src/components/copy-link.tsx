"use client";

import { useState } from "react";
import { cn } from "@/components/ui";

/**
 * Copies the creator's own URL.
 *
 * Falls back to selecting the text when the clipboard API is unavailable -- it needs a
 * secure context, and this is the one control on the page whose whole purpose is to hand
 * the creator something to paste.
 */
export function CopyLink({ url, className }: { url: string; className?: string }) {
  const [state, setState] = useState<"idle" | "copied" | "failed">("idle");

  async function copy() {
    try {
      await navigator.clipboard.writeText(url);
      setState("copied");
    } catch {
      setState("failed");
    }
    setTimeout(() => setState("idle"), 2000);
  }

  const shown = url.replace(/^https?:\/\//, "");

  return (
    <button
      type="button"
      onClick={copy}
      title={`Copy ${url}`}
      className={cn(
        "group flex max-w-full items-center gap-2 rounded-lg border border-border px-3 py-2",
        "text-xs text-ink-600 hover:bg-ink-50",
        className,
      )}
    >
      <span className="truncate">{shown}</span>
      <span className="shrink-0 font-medium text-ink-800">
        {state === "copied" ? "copied" : state === "failed" ? "select it" : "copy"}
      </span>
    </button>
  );
}
