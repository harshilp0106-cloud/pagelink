"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Alert, Button } from "@/components/ui";
import { setPublished } from "@/app/(app)/settings/actions";

/**
 * Says the page is private, and offers the one button that changes it.
 *
 * A pill in the sidebar was not enough: creators built a page, copied the link, sent it to
 * someone and got a 404 back, because publishing lived on a settings screen they had no
 * reason to open. The state has to be said where the work happens.
 */
export function PublishBanner({ url }: { url: string }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  function publish() {
    start(async () => {
      const result = await setPublished(true);
      if (result.error) {
        setError(result.error);
        return;
      }
      router.refresh();
    });
  }

  return (
    <Alert tone="warn">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <span>
          Your page is private. {url.replace(/^https?:\/\//, "")} will not open for anyone
          else until you publish it.
        </span>
        <Button size="sm" onClick={publish} disabled={pending}>
          {pending ? "Publishing..." : "Publish my page"}
        </Button>
      </div>
      {error && <p className="mt-2 text-xs text-red-600">{error}</p>}
    </Alert>
  );
}
