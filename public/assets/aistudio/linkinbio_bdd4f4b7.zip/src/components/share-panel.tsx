"use client";

import { useEffect, useState } from "react";

/**
 * Share, on the creator's own page.
 *
 * The QR is rendered on the server and arrives as an image, so the page carries no encoder
 * and the code is identical for every visitor. It always sits on white: a QR drawn in a
 * theme's colours looks better and scans worse, and the point of it is being scanned from
 * somebody's phone across a table.
 *
 * Native sharing is offered when the browser has it -- on a phone that is the sheet people
 * already know -- and copying is always there, because desktop browsers mostly do not.
 */
export function SharePanel({ url, qr }: { url: string; qr: string }) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  /*
   * Read at render rather than stored from an effect. The value differs between the server
   * and the browser, but it is only used inside the dialog, which does not exist until the
   * visitor opens it -- so the first render matches on both sides and there is nothing to
   * hydrate wrongly.
   */
  const canShare = typeof navigator !== "undefined" && typeof navigator.share === "function";

  useEffect(() => {
    if (!open) return;
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  async function copy() {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard access needs a secure context; the address is on screen to copy by hand.
    }
  }

  async function share() {
    try {
      await navigator.share({ url });
    } catch {
      // The visitor dismissed the sheet, which is not a failure worth reporting.
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Share this page"
        className="absolute top-4 right-4 flex size-10 items-center justify-center rounded-full bg-current/10 transition-opacity hover:opacity-80"
      >
        <svg viewBox="0 0 24 24" className="size-5" fill="currentColor" aria-hidden="true">
          <path d="M18 8a3 3 0 1 0-2.8-4H15a3 3 0 0 0 .2 1.1L8.8 8.9a3 3 0 1 0 0 6.2l6.4 3.8A3 3 0 1 0 18 16a3 3 0 0 0-2 .8l-6.2-3.7a3 3 0 0 0 0-2.2L16 7.2A3 3 0 0 0 18 8Z" />
        </svg>
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-5"
          onClick={() => setOpen(false)}
          role="presentation"
        >
          <div
            className="flex w-full max-w-xs flex-col items-center gap-4 p-5"
            style={{
              background: "var(--card-bg)",
              color: "var(--card-fg)",
              borderRadius: "var(--card-radius, 0.875rem)",
            }}
            onClick={(event) => event.stopPropagation()}
          >
            <p className="text-sm font-semibold">Share this page</p>

            <div className="rounded-lg bg-white p-3">
              {/* A plain img: the source is a data URI generated per request, which is
                  exactly the case next/image has nothing to add to. */}
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={qr} alt="QR code for this page" width={180} height={180} />
            </div>

            <p className="w-full truncate text-center text-xs opacity-70">
              {url.replace(/^https?:\/\//, "")}
            </p>

            <div className="flex w-full flex-col gap-2">
              <button
                type="button"
                onClick={copy}
                className="w-full rounded-lg bg-current/10 px-4 py-2.5 text-sm font-medium"
              >
                {copied ? "Copied" : "Copy link"}
              </button>

              {canShare && (
                <button
                  type="button"
                  onClick={share}
                  className="w-full rounded-lg bg-current/10 px-4 py-2.5 text-sm font-medium"
                >
                  Share
                </button>
              )}

              <button
                type="button"
                onClick={() => setOpen(false)}
                className="w-full px-4 py-1 text-xs opacity-60"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
