import Link from "next/link";

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-screen w-full max-w-md flex-col justify-center gap-3 px-6 text-center">
      <h1 className="text-2xl font-semibold text-ink-900">Nothing here</h1>
      <p className="text-sm text-ink-500">
        This page does not exist, or the creator has not published it yet.
      </p>
      <Link href="/" className="text-sm font-medium text-ink-800 hover:underline">
        Go to the home page
      </Link>
    </main>
  );
}
