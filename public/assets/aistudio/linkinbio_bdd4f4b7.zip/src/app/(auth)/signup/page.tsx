"use client";

import { useCallback, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Alert, Button, Card, Field, Input } from "@/components/ui";
import { GoogleButton } from "@/components/google-button";
import { HandleField, type HandleState } from "@/components/handle-field";

export default function SignupPage() {
  const router = useRouter();

  const [name, setName] = useState("");
  const [handle, setHandle] = useState("");
  const [handleState, setHandleState] = useState<HandleState>("empty");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  const trackHandle = useCallback((state: HandleState) => setHandleState(state), []);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (handleState !== "free") {
      setError("Pick a handle that is available first.");
      return;
    }

    setBusy(true);
    setError(null);
    const supabase = createClient();

    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        // Carried on the account so the handle survives an email confirmation round trip:
        // the profile row cannot be written until the creator is actually signed in.
        data: { handle: handle.trim().toLowerCase(), display_name: name.trim() },
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });

    if (signUpError) {
      setError(signUpError.message);
      setBusy(false);
      return;
    }

    // With email confirmation switched on there is no session yet, so the profile is claimed
    // later, on the onboarding page. With it off, the account is usable now.
    if (!data.session) {
      setSent(true);
      setBusy(false);
      return;
    }

    const { error: claimError } = await supabase.rpc("claim_handle", {
      p_handle: handle.trim().toLowerCase(),
      p_display_name: name.trim(),
    });

    if (claimError) {
      // The account exists either way, so send them on rather than stranding them here.
      router.replace("/onboarding");
      return;
    }

    router.refresh();
    router.replace("/editor");
  }

  if (sent) {
    return (
      <Card className="flex flex-col gap-3 p-6">
        <h1 className="text-lg font-semibold text-ink-900">Check your email</h1>
        <p className="text-sm text-ink-500">
          We sent a confirmation link to {email}. Open it and your page at /@{handle} is
          yours.
        </p>
        <Link href="/login" className="text-sm font-medium text-ink-800 hover:underline">
          Back to sign in
        </Link>
      </Card>
    );
  }

  return (
    <Card className="flex flex-col gap-5 p-6">
      <div>
        <h1 className="text-lg font-semibold text-ink-900">Create your page</h1>
        <p className="mt-0.5 text-sm text-ink-500">One link for everything you share.</p>
      </div>

      {error && <Alert tone="bad">{error}</Alert>}

      <form onSubmit={submit} className="flex flex-col gap-4">
        <Field label="Your name" htmlFor="name">
          <Input
            id="name"
            required
            maxLength={60}
            value={name}
            onChange={(event) => setName(event.target.value)}
          />
        </Field>

        <HandleField value={handle} onChange={setHandle} onStateChange={trackHandle} />

        <Field label="Email" htmlFor="email">
          <Input
            id="email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />
        </Field>

        <Field label="Password" htmlFor="password" hint="At least eight characters.">
          <Input
            id="password"
            type="password"
            autoComplete="new-password"
            required
            minLength={8}
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />
        </Field>

        <Button type="submit" disabled={busy || handleState === "checking"}>
          {busy ? "Creating..." : "Create account"}
        </Button>
      </form>

      <div className="flex items-center gap-3 text-xs text-ink-300">
        <span className="h-px flex-1 bg-border" />
        or
        <span className="h-px flex-1 bg-border" />
      </div>

      <GoogleButton label="Sign up with Google" />

      <p className="text-xs text-ink-500">
        Already have an account?{" "}
        <Link href="/login" className="font-medium text-ink-800 hover:underline">
          Sign in
        </Link>
      </p>
    </Card>
  );
}
