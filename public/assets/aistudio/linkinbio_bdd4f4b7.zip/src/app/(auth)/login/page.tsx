import { Suspense } from "react";
import { Card } from "@/components/ui";
import { LoginForm } from "./login-form";

/**
 * The form reads the query string -- `next`, and any reason the auth callback handed back --
 * which a statically rendered page cannot know, so it renders inside Suspense. Without the
 * boundary the build refuses to prerender this page at all.
 */
export default function LoginPage() {
  return (
    <Suspense fallback={<Card className="h-72 animate-pulse bg-ink-50" />}>
      <LoginForm />
    </Suspense>
  );
}
