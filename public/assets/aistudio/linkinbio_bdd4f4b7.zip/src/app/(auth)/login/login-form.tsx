"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Alert, Button, Card, Field, Input } from "@/components/ui";
import { GoogleButton } from "@/components/google-button";

export function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next");
  // The auth callback redirects here with a reason when an emailed link or an OAuth
  // round trip fails, and that reason is the only explanation the creator ever gets.
  const handedBack = params.get("error");

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);

    const supabase = createClient();
    const { error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
      // Supabase says "Invalid login credentials" for a wrong password and for an address
      // that has no account, which is the right amount to say -- anything more precise
      // tells a stranger which addresses are registered.
      setError(error.message);
      setBusy(false);
      return;
    }

    // refresh() first, so the server components behind the redirect see the new cookie.
    router.refresh();
    router.replace(next && next.startsWith("/") ? next : "/editor");
  }

  return (
    <Card className="flex flex-col gap-5 p-6">
      <div>
        <h1 className="text-lg font-semibold text-ink-900">Sign in</h1>
        <p className="mt-0.5 text-sm text-ink-500">Pick up where you left off.</p>
      </div>

      {(error ?? handedBack) && <Alert tone="bad">{error ?? handedBack}</Alert>}

      <form onSubmit={submit} className="flex flex-col gap-4">
        <Field label="Email" htmlFor="email">
          <Input
            id="email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />
        </Field>

        <Field label="Password" htmlFor="password">
          <Input
            id="password"
            type="password"
            autoComplete="current-password"
            required
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />
        </Field>

        <Button type="submit" disabled={busy}>
          {busy ? "Signing in..." : "Sign in"}
        </Button>
      </form>

      <div className="flex items-center gap-3 text-xs text-ink-300">
        <span className="h-px flex-1 bg-border" />
        or
        <span className="h-px flex-1 bg-border" />
      </div>

      <GoogleButton label="Sign in with Google" />

      <div className="flex justify-between text-xs text-ink-500">
        <Link href="/forgot-password" className="hover:underline">
          Forgot password
        </Link>
        <Link href="/signup" className="font-medium text-ink-800 hover:underline">
          Create an account
        </Link>
      </div>
    </Card>
  );
}
