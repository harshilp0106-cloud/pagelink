"use client";

import { useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { Alert, Button, Card, Field, Input } from "@/components/ui";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);

    const supabase = createClient();
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/auth/callback?next=/reset-password`,
    });

    if (error) {
      setError(error.message);
      setBusy(false);
      return;
    }

    // Says the same thing whether or not the address has an account, so this page cannot be
    // used to find out who is registered.
    setSent(true);
    setBusy(false);
  }

  return (
    <Card className="flex flex-col gap-5 p-6">
      <div>
        <h1 className="text-lg font-semibold text-ink-900">Reset your password</h1>
        <p className="mt-0.5 text-sm text-ink-500">
          We will email you a link to set a new one.
        </p>
      </div>

      {error && <Alert tone="bad">{error}</Alert>}
      {sent && <Alert tone="good">If that address has an account, the link is on its way.</Alert>}

      <form onSubmit={submit} className="flex flex-col gap-4">
        <Field label="Email" htmlFor="email">
          <Input
            id="email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />
        </Field>
        <Button type="submit" disabled={busy}>
          {busy ? "Sending..." : "Send the link"}
        </Button>
      </form>

      <Link href="/login" className="text-xs font-medium text-ink-800 hover:underline">
        Back to sign in
      </Link>
    </Card>
  );
}
