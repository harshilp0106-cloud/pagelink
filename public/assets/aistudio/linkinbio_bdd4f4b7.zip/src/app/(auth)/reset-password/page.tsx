"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Alert, Button, Card, Field, Input } from "@/components/ui";

/**
 * Sets a new password.
 *
 * Reached from the emailed link, which the auth callback has already exchanged for a
 * session -- so this page has a signed-in user and simply updates them. Without that
 * session there is nothing to update, which is why it checks first and says so.
 */
export default function ResetPasswordPage() {
  const router = useRouter();
  const [ready, setReady] = useState<boolean | null>(null);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const supabase = createClient();
    supabase.auth.getUser().then(({ data }) => setReady(!!data.user));
  }, []);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);

    const supabase = createClient();
    const { error } = await supabase.auth.updateUser({ password });

    if (error) {
      setError(error.message);
      setBusy(false);
      return;
    }

    router.refresh();
    router.replace("/editor");
  }

  if (ready === false) {
    return (
      <Card className="flex flex-col gap-3 p-6">
        <h1 className="text-lg font-semibold text-ink-900">This link has expired</h1>
        <p className="text-sm text-ink-500">
          Reset links are single use and time limited. Ask for a fresh one.
        </p>
        <Button onClick={() => router.push("/forgot-password")}>Send a new link</Button>
      </Card>
    );
  }

  return (
    <Card className="flex flex-col gap-5 p-6">
      <h1 className="text-lg font-semibold text-ink-900">Choose a new password</h1>

      {error && <Alert tone="bad">{error}</Alert>}

      <form onSubmit={submit} className="flex flex-col gap-4">
        <Field label="New password" htmlFor="password" hint="At least eight characters.">
          <Input
            id="password"
            type="password"
            autoComplete="new-password"
            required
            minLength={8}
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />
        </Field>
        <Button type="submit" disabled={busy || ready === null}>
          {busy ? "Saving..." : "Save password"}
        </Button>
      </form>
    </Card>
  );
}
