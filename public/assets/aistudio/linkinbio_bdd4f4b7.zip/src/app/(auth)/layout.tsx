import Link from "next/link";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col justify-center px-5 py-10">
      <Link href="/" className="mb-6 self-start text-sm font-semibold text-ink-900">
        Link in Bio
      </Link>
      {children}
    </div>
  );
}
