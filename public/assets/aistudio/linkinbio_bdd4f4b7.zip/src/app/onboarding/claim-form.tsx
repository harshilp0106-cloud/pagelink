"use client";

import { useCallback, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Alert, Button, Card, Field, Input } from "@/components/ui";
import { HandleField, type HandleState } from "@/components/handle-field";

const MESSAGES: Record<string, string> = {
  handle_unavailable: "That handle just went. Try another.",
  profile_exists: "You already have a page.",
  not_signed_in: "Your session expired. Sign in again.",
};

export function ClaimForm({ handle: initialHandle, name: initialName }: { handle: string; name: string }) {
  const router = useRouter();
  const [handle, setHandle] = useState(initialHandle);
  const [name, setName] = useState(initialName);
  const [handleState, setHandleState] = useState<HandleState>("empty");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const trackHandle = useCallback((state: HandleState) => setHandleState(state), []);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (handleState !== "free") {
      setError("Pick a handle that is available first.");
      return;
    }

    setBusy(true);
    setError(null);

    const supabase = createClient();
    const { error } = await supabase.rpc("claim_handle", {
      p_handle: handle.trim().toLowerCase(),
      p_display_name: name.trim(),
    });

    if (error) {
      const key = Object.keys(MESSAGES).find((code) => error.message.includes(code));
      setError(key ? MESSAGES[key] : error.message);
      setBusy(false);
      if (key === "profile_exists") router.replace("/editor");
      return;
    }

    router.refresh();
    router.replace("/editor");
  }

  return (
    <Card className="flex flex-col gap-5 p-6">
      <div>
        <h1 className="text-lg font-semibold text-ink-900">Claim your handle</h1>
        <p className="mt-0.5 text-sm text-ink-500">
          This is the link you will share, so pick the one you want people to remember.
        </p>
      </div>

      {error && <Alert tone="bad">{error}</Alert>}

      <form onSubmit={submit} className="flex flex-col gap-4">
        <HandleField value={handle} onChange={setHandle} onStateChange={trackHandle} />

        <Field label="Display name" htmlFor="name" hint="Shown at the top of your page.">
          <Input
            id="name"
            required
            maxLength={60}
            value={name}
            onChange={(event) => setName(event.target.value)}
          />
        </Field>

        <Button type="submit" disabled={busy || handleState === "checking"}>
          {busy ? "Setting up..." : "Continue"}
        </Button>
      </form>
    </Card>
  );
}
