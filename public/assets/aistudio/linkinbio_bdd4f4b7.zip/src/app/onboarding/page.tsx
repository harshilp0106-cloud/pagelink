import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { ClaimForm } from "./claim-form";

/**
 * Picking a handle.
 *
 * Sits outside the editor's layout on purpose: there is no page to navigate around yet, and
 * a sidebar full of links that all bounce back here reads as broken.
 */
export default async function OnboardingPage() {
  const user = await requireUser();
  const supabase = await createClient();

  const { data: profile } = await supabase
    .from("profiles")
    .select("id")
    .eq("id", user.id)
    .maybeSingle();

  if (profile) redirect("/editor");

  const meta = user.user_metadata ?? {};
  const suggestedHandle = typeof meta.handle === "string" ? meta.handle : "";
  const suggestedName =
    (typeof meta.display_name === "string" && meta.display_name) ||
    (typeof meta.full_name === "string" && meta.full_name) ||
    (typeof meta.name === "string" && meta.name) ||
    "";

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col justify-center px-5 py-10">
      <ClaimForm handle={suggestedHandle} name={suggestedName} />
    </div>
  );
}
