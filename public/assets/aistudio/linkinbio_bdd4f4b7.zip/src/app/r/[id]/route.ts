import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Counts a click and forwards the visitor.
 *
 * The destination comes back from the database rather than from the URL, so this route
 * cannot be turned into an open redirector by anyone who can write a link. It also means a
 * hidden link, a section header, or a page that has been unpublished simply does not
 * forward -- the database decides, in one call that both records and answers.
 */
export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const home = new URL("/", request.nextUrl.origin);

  if (!UUID.test(id)) return NextResponse.redirect(home);

  const supabase = await createClient();
  const { data: url, error } = await supabase.rpc("follow_link", {
    p_link: id,
    p_referrer: request.headers.get("referer"),
  });

  if (error || typeof url !== "string") return NextResponse.redirect(home);

  // 302, not 301: a permanent redirect would be cached by the browser and every later click
  // on that link would never reach us to be counted.
  return NextResponse.redirect(url, 302);
}
