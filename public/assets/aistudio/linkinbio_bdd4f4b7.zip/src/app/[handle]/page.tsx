import type { Metadata } from "next";
import Link from "next/link";
import { headers } from "next/headers";
import { notFound, permanentRedirect } from "next/navigation";
import QRCode from "qrcode";
import { createClient } from "@/lib/supabase/server";
import { siteUrl } from "@/lib/env";
import { readTheme } from "@/lib/theme";
import { CreatorPage } from "@/components/creator-page";
import type { PageLink, Profile, Social } from "@/lib/types";

/**
 * A creator's page, at /@handle.
 *
 * Never cached: it counts its own views, and a creator who changes a link expects to see it
 * changed when they reload. The page is small and the queries are indexed, so there is
 * little to gain from caching it anyway.
 */
export const dynamic = "force-dynamic";

/** `@handle` in the URL, `handle` in the database. A bare handle is redirected to the @ form. */
function readHandle(raw: string): { handle: string; canonical: boolean } {
  const decoded = decodeURIComponent(raw);
  return decoded.startsWith("@")
    ? { handle: decoded.slice(1).toLowerCase(), canonical: true }
    : { handle: decoded.toLowerCase(), canonical: false };
}

async function load(raw: string) {
  const { handle } = readHandle(raw);
  if (!handle) return null;

  const supabase = await createClient();

  // The read policy already hides unpublished profiles from anyone but their owner, so a
  // creator previewing their own unpublished page still sees it here.
  const { data: profile, error } = await supabase
    .from("profiles")
    .select("id, handle, display_name, bio, avatar_url, banner_url, theme, is_published")
    .eq("handle", handle)
    .maybeSingle();

  /*
   * A failed query is not a missing page.
   *
   * maybeSingle() reports no rows as data: null with no error, so anything in `error` is a
   * real fault -- a column this build expects and the database has not got yet, most of
   * all. Swallowing it turned "the migration has not been run" into "this creator does not
   * exist", which is the most misleading 404 there is.
   */
  if (error) throw new Error(`Could not load @${handle}: ${error.message}`);
  if (!profile) return null;

  const [{ data: links }, { data: socials }] = await Promise.all([
    supabase
      .from("links")
      .select("*")
      .eq("profile_id", profile.id)
      .order("position")
      .order("created_at")
      .returns<PageLink[]>(),
    supabase
      .from("socials")
      .select("*")
      .eq("profile_id", profile.id)
      .order("position")
      .returns<Social[]>(),
  ]);

  return {
    profile: { ...profile, theme: readTheme(profile.theme) } as Profile,
    links: links ?? [],
    socials: socials ?? [],
  };
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ handle: string }>;
}): Promise<Metadata> {
  const { handle } = await params;
  const loaded = await load(handle);
  if (!loaded) return { title: "Page not found" };

  const name = loaded.profile.display_name || `@${loaded.profile.handle}`;
  const description = loaded.profile.bio ?? `Everything from ${name}, in one place.`;

  return {
    title: name,
    description,
    openGraph: {
      title: name,
      description,
      type: "profile",
      images: loaded.profile.avatar_url ? [loaded.profile.avatar_url] : undefined,
    },
    twitter: { card: "summary" },
    robots: loaded.profile.is_published ? undefined : { index: false, follow: false },
  };
}

export default async function PublicPage({ params }: { params: Promise<{ handle: string }> }) {
  const { handle: raw } = await params;
  const { handle, canonical } = readHandle(raw);

  const loaded = await load(raw);
  if (!loaded) notFound();

  // One address per page, so a link shared as /karan and a link shared as /@karan do not
  // count as two different pages in the creator's own analytics.
  if (!canonical) permanentRedirect(`/@${handle}`);

  const supabase = await createClient();
  const referrer = (await headers()).get("referer");
  // Records nothing for an unpublished page -- the function checks that itself.
  await supabase.rpc("track_view", { p_handle: handle, p_referrer: referrer });

  // Drawn here rather than in the browser, so the page ships no encoder and every visitor
  // scans the same image. Quartile M correction: a QR held up on a phone screen is rarely
  // damaged, and lower correction keeps the pattern coarse enough to read quickly.
  const pageUrl = `${siteUrl()}/@${handle}`;
  const qrImage = await QRCode.toDataURL(pageUrl, {
    margin: 1,
    width: 360,
    errorCorrectionLevel: "M",
    color: { dark: "#000000ff", light: "#ffffffff" },
  });

  return (
    <main className="min-h-screen">
      {/*
        An unpublished page still opens for its owner, so they can see it before anyone else
        can. Signed in in one tab and not in another is exactly when that looks like a bug,
        so the page says which of the two is happening.
      */}
      {!loaded.profile.is_published && (
        <p className="bg-amber-100 px-4 py-2 text-center text-sm text-amber-900">
          Not published. Only you can see this page while you are signed in.{" "}
          <Link href="/settings" className="font-medium underline">
            Publish it
          </Link>
        </p>
      )}

      <CreatorPage
        profile={loaded.profile}
        links={loaded.links}
        socials={loaded.socials}
        mode="live"
        share={{ url: pageUrl, qr: qrImage }}
      />
    </main>
  );
}
