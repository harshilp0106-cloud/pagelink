import type { Metadata } from "next";
import { Inter, JetBrains_Mono, Playfair_Display, Poppins } from "next/font/google";
import "./globals.css";

/**
 * Four families, loaded once at the root, exposed as custom properties.
 *
 * A creator picks a font per page, so all four have to be available on any page they might
 * share -- but the families are loaded here rather than per theme, because a font switched
 * at render time would arrive after the text and reflow the page in front of the visitor.
 */
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const poppins = Poppins({
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  variable: "--font-poppins",
  display: "swap",
});
const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
});
const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Link in Bio",
  description: "One link for everything a creator wants to share.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${poppins.variable} ${playfair.variable} ${jetbrains.variable}`}
    >
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
