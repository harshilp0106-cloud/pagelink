import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";

/**
 * Where every emailed link and every OAuth round trip comes back to.
 *
 * Supabase hands back a one-time code; exchanging it here rather than in the browser means
 * the session is written as an HTTP-only cookie the page's JavaScript cannot read.
 */
export async function GET(request: NextRequest) {
  const { searchParams, origin } = request.nextUrl;
  const code = searchParams.get("code");
  const next = searchParams.get("next");

  // Only ever redirect within this site: `next` arrives from a URL anyone can write.
  const destination = next && next.startsWith("/") && !next.startsWith("//") ? next : "/editor";

  if (!code) {
    const error = searchParams.get("error_description") ?? searchParams.get("error");
    const url = new URL("/login", origin);
    if (error) url.searchParams.set("error", error);
    return NextResponse.redirect(url);
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.exchangeCodeForSession(code);

  if (error) {
    const url = new URL("/login", origin);
    url.searchParams.set("error", error.message);
    return NextResponse.redirect(url);
  }

  return NextResponse.redirect(new URL(destination, origin));
}
