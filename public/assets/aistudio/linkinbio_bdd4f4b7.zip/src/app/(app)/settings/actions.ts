"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireProfile } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";

type Result = { error?: string };

export async function setPublished(published: boolean): Promise<Result> {
  const profile = await requireProfile();
  const supabase = await createClient();

  const { error } = await supabase
    .from("profiles")
    .update({ is_published: published })
    .eq("id", profile.id);

  if (error) return { error: error.message };

  revalidatePath("/settings");
  revalidatePath("/editor");
  revalidatePath(`/@${profile.handle}`);
  return {};
}

/**
 * Moves the creator to a new handle.
 *
 * The old URL stops working immediately, which is the honest behaviour: keeping it alive
 * would mean two live addresses for one page, two sets of view counts, and a name nobody
 * else can ever claim.
 */
export async function updateHandle(raw: string): Promise<Result> {
  const profile = await requireProfile();

  const parsed = z
    .string()
    .trim()
    .toLowerCase()
    .regex(/^[a-z0-9][a-z0-9_.-]{1,28}[a-z0-9]$/, "Three to thirty characters.")
    .safeParse(raw);

  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "That handle is not valid." };
  }

  const supabase = await createClient();
  const { error } = await supabase.rpc("change_handle", { p_handle: parsed.data });

  if (error) {
    return {
      error: error.message.includes("handle_unavailable")
        ? "That handle is taken."
        : error.message,
    };
  }

  revalidatePath("/settings");
  revalidatePath("/editor");
  revalidatePath(`/@${profile.handle}`);
  revalidatePath(`/@${parsed.data}`);
  return {};
}

/**
 * Deletes the account.
 *
 * Needs the service role: a creator cannot remove their own row from auth.users, and
 * leaving the login behind while the page is gone is worse than either outcome. Everything
 * else follows from the foreign keys.
 */
export async function deleteAccount(): Promise<Result> {
  const profile = await requireProfile();
  const admin = createAdminClient();

  const { error } = await admin.auth.admin.deleteUser(profile.id);
  if (error) return { error: error.message };

  const supabase = await createClient();
  await supabase.auth.signOut();
  return {};
}
