import { requireProfile } from "@/lib/auth";
import { siteUrl } from "@/lib/env";
import { PageHeader } from "@/components/ui";
import { SettingsPanels } from "./settings-panels";

export default async function SettingsPage() {
  const profile = await requireProfile();

  return (
    <div className="flex max-w-2xl flex-col gap-5">
      <PageHeader title="Settings" subtitle="Your address, your account." />
      <SettingsPanels profile={profile} origin={siteUrl()} />
    </div>
  );
}
