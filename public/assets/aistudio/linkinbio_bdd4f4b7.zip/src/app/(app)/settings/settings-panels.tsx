"use client";

import { useCallback, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Alert, Button, Card, Field, Input } from "@/components/ui";
import { HandleField, type HandleState } from "@/components/handle-field";
import type { Profile } from "@/lib/types";
import { deleteAccount, setPublished, updateHandle } from "./actions";

export function SettingsPanels({ profile, origin }: { profile: Profile; origin: string }) {
  const router = useRouter();
  const [handle, setHandle] = useState(profile.handle);
  const [handleState, setHandleState] = useState<HandleState>("free");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState<{ tone: "good" | "bad"; text: string } | null>(null);
  const [confirmDelete, setConfirmDelete] = useState("");
  const [pending, start] = useTransition();

  const trackHandle = useCallback((state: HandleState) => setHandleState(state), []);

  function run(action: () => Promise<{ error?: string }>, done?: string) {
    start(async () => {
      const result = await action();
      setMessage(
        result.error
          ? { tone: "bad", text: result.error }
          : { tone: "good", text: done ?? "Saved." },
      );
      if (!result.error) router.refresh();
    });
  }

  async function changePassword(event: React.FormEvent) {
    event.preventDefault();
    const supabase = createClient();
    const { error } = await supabase.auth.updateUser({ password });
    setPassword("");
    setMessage(
      error
        ? { tone: "bad", text: error.message }
        : { tone: "good", text: "Password changed." },
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {message && <Alert tone={message.tone}>{message.text}</Alert>}

      <Card className="flex flex-col gap-3">
        <h2 className="text-sm font-semibold text-ink-800">Publishing</h2>
        <p className="text-sm text-ink-500">
          {profile.is_published
            ? "Your page is live and anyone with the link can open it."
            : "Your page is private. Only you can see it while you are signed in."}
        </p>
        <div className="flex flex-wrap items-center gap-3">
          <Button
            type="button"
            variant={profile.is_published ? "outline" : "primary"}
            disabled={pending}
            onClick={() =>
              run(
                () => setPublished(!profile.is_published),
                profile.is_published ? "Your page is private again." : "Your page is live.",
              )
            }
          >
            {profile.is_published ? "Unpublish" : "Publish my page"}
          </Button>
          <span className="text-xs text-ink-400">
            {origin}/@{profile.handle}
          </span>
        </div>
      </Card>

      <Card className="flex flex-col gap-3">
        <h2 className="text-sm font-semibold text-ink-800">Your handle</h2>
        <HandleField
          value={handle}
          onChange={setHandle}
          onStateChange={trackHandle}
          currentHandle={profile.handle}
          label="Handle"
        />
        <p className="text-xs text-ink-400">
          Changing this changes your link. The old one stops working, so update it wherever
          you have shared it.
        </p>
        <div>
          <Button
            type="button"
            disabled={
              pending || handleState !== "free" || handle.toLowerCase() === profile.handle
            }
            onClick={() => run(() => updateHandle(handle), "Your handle is updated.")}
          >
            Save handle
          </Button>
        </div>
      </Card>

      <Card className="flex flex-col gap-3">
        <h2 className="text-sm font-semibold text-ink-800">Password</h2>
        <form onSubmit={changePassword} className="flex flex-col gap-3">
          <Field label="New password" htmlFor="password" hint="At least eight characters.">
            <Input
              id="password"
              type="password"
              autoComplete="new-password"
              minLength={8}
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </Field>
          <div>
            <Button type="submit" variant="outline">
              Change password
            </Button>
          </div>
        </form>
      </Card>

      <Card className="flex flex-col gap-3 border-red-200">
        <h2 className="text-sm font-semibold text-ink-800">Delete account</h2>
        <p className="text-sm text-ink-500">
          This removes your page, your links and everything they have collected. It cannot be
          undone.
        </p>
        <Field label={`Type ${profile.handle} to confirm`} htmlFor="confirm">
          <Input
            id="confirm"
            value={confirmDelete}
            onChange={(event) => setConfirmDelete(event.target.value)}
          />
        </Field>
        <div>
          <Button
            type="button"
            variant="danger"
            disabled={pending || confirmDelete.trim().toLowerCase() !== profile.handle}
            onClick={() =>
              start(async () => {
                const result = await deleteAccount();
                if (result.error) {
                  setMessage({ tone: "bad", text: result.error });
                  return;
                }
                router.replace("/");
              })
            }
          >
            Delete my account
          </Button>
        </div>
      </Card>
    </div>
  );
}
