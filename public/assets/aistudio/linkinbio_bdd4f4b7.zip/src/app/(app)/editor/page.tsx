import { requireProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { siteUrl } from "@/lib/env";
import { PageHeader } from "@/components/ui";
import { PublishBanner } from "@/components/publish-banner";
import type { PageLink, Social } from "@/lib/types";
import { LinkWorkspace } from "./link-workspace";

export default async function EditorPage() {
  const profile = await requireProfile();
  const supabase = await createClient();

  const [{ data: links }, { data: socials }] = await Promise.all([
    supabase
      .from("links")
      .select("*")
      .eq("profile_id", profile.id)
      .order("position")
      .order("created_at")
      .returns<PageLink[]>(),
    supabase
      .from("socials")
      .select("*")
      .eq("profile_id", profile.id)
      .order("position")
      .returns<Social[]>(),
  ]);

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title="Links"
        subtitle="Add what you share, drag to reorder, hide anything you are not using."
      />

      {!profile.is_published && <PublishBanner url={`${siteUrl()}/@${profile.handle}`} />}
      <LinkWorkspace profile={profile} links={links ?? []} socials={socials ?? []} />
    </div>
  );
}
