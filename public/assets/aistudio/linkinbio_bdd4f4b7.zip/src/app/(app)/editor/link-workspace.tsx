"use client";

import { useRef, useState, useTransition } from "react";
import { Alert, Button, Card, Input, Select, cn } from "@/components/ui";
import { CreatorPage } from "@/components/creator-page";
import { PhoneFrame } from "@/components/phone-frame";
import { SocialIcon, isIconKey } from "@/components/social-icon";
import { iconForUrl } from "@/lib/links";
import type { PageLink, Profile, Social } from "@/lib/types";
import { addEmbed, addHeader, addLink, deleteLink, reorder, saveLink } from "./actions";

type Draft = { kind: "link" | "embed" | "header"; title: string; url: string };

const EMPTY_DRAFT: Draft = { kind: "link", title: "", url: "" };

/**
 * The links editor, with the page beside it.
 *
 * Every change is applied to local state first and sent afterwards. A creator dragging six
 * rows into place should not watch each one snap back while a request finishes, and the
 * revert path below puts the server's answer back if a write does fail.
 */
export function LinkWorkspace({
  profile,
  links,
  socials,
}: {
  profile: Profile;
  links: PageLink[];
  socials: Social[];
}) {
  const [rows, setRows] = useState(links);
  const [draft, setDraft] = useState<Draft>(EMPTY_DRAFT);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const dragging = useRef<string | null>(null);

  // The server is the source of truth. Adjusting during render rather than in an effect is
  // React's own answer to "props changed, reset some state": an effect would render the
  // stale list first and replace it a frame later.
  const [known, setKnown] = useState(links);
  if (known !== links) {
    setKnown(links);
    setRows(links);
  }

  function run(action: () => Promise<{ error?: string }>, revert?: () => void) {
    start(async () => {
      const result = await action();
      if (result.error) {
        setError(result.error);
        revert?.();
      } else {
        setError(null);
      }
    });
  }

  function submitDraft(event: React.FormEvent) {
    event.preventDefault();
    const { kind, title, url } = draft;
    setDraft(EMPTY_DRAFT);

    if (kind === "header") {
      run(() => addHeader(title));
    } else if (kind === "embed") {
      run(() => addEmbed(url, title));
    } else {
      run(() => addLink(title, url));
    }
  }

  function move(from: number, to: number) {
    if (to < 0 || to >= rows.length || from === to) return;
    const next = [...rows];
    const [row] = next.splice(from, 1);
    next.splice(to, 0, row);
    const previous = rows;
    setRows(next);
    run(
      () => reorder(next.map((item) => item.id)),
      () => setRows(previous),
    );
  }

  function patch(id: string, values: Partial<PageLink>) {
    const previous = rows;
    setRows((current) =>
      current.map((row) => (row.id === id ? { ...row, ...values } : row)),
    );
    run(
      () =>
        saveLink(id, {
          title: values.title,
          url: values.url ?? undefined,
          embed_mode: values.embed_mode,
          is_visible: values.is_visible,
        }),
      () => setRows(previous),
    );
  }

  function remove(id: string) {
    const previous = rows;
    setRows((current) => current.filter((row) => row.id !== id));
    run(
      () => deleteLink(id),
      () => setRows(previous),
    );
  }

  return (
    <div className="flex flex-col gap-6 xl:flex-row">
      <div className="flex min-w-0 flex-1 flex-col gap-4">
        <Card className="flex flex-col gap-3">
          <form onSubmit={submitDraft} className="flex flex-col gap-3">
            <div className="flex flex-wrap gap-2">
              <Select
                aria-label="What to add"
                value={draft.kind}
                onChange={(event) =>
                  setDraft({ ...draft, kind: event.target.value as Draft["kind"] })
                }
                className="w-auto"
              >
                <option value="link">Link</option>
                <option value="embed">Video or track</option>
                <option value="header">Section title</option>
              </Select>

              {draft.kind !== "header" && (
                <Input
                  aria-label="URL"
                  placeholder={
                    draft.kind === "embed"
                      ? "youtube.com/watch?v=... or open.spotify.com/..."
                      : "yourshop.com/collection"
                  }
                  value={draft.url}
                  onChange={(event) => setDraft({ ...draft, url: event.target.value })}
                  required
                  className="min-w-52 flex-1"
                />
              )}

              <Input
                aria-label="Title"
                placeholder={draft.kind === "header" ? "Section title" : "Title (optional)"}
                value={draft.title}
                onChange={(event) => setDraft({ ...draft, title: event.target.value })}
                required={draft.kind === "header"}
                maxLength={80}
                className="min-w-40 flex-1"
              />

              <Button type="submit" disabled={pending}>
                Add
              </Button>
            </div>

            {draft.kind === "embed" && (
              <p className="text-xs text-ink-400">
                YouTube and Spotify play on the page. Instagram posts show as a card that
                opens the post, because Instagram no longer allows a reliable inline embed.
              </p>
            )}
          </form>
        </Card>

        {error && <Alert tone="bad">{error}</Alert>}

        {rows.length === 0 ? (
          <div className="rounded-card border border-dashed border-border px-6 py-10 text-center">
            <p className="font-medium text-ink-800">Nothing on your page yet</p>
            <p className="mx-auto mt-1 max-w-sm text-sm text-ink-500">
              Add your first link above and it appears in the preview straight away.
            </p>
          </div>
        ) : (
          <ul className="flex flex-col gap-2">
            {rows.map((row, index) => (
              <li
                key={row.id}
                draggable
                onDragStart={() => (dragging.current = row.id)}
                onDragEnd={() => (dragging.current = null)}
                onDragOver={(event) => event.preventDefault()}
                onDrop={(event) => {
                  event.preventDefault();
                  const from = rows.findIndex((item) => item.id === dragging.current);
                  if (from >= 0) move(from, index);
                  dragging.current = null;
                }}
              >
                <RowCard
                  row={row}
                  index={index}
                  total={rows.length}
                  busy={pending}
                  onMove={move}
                  onPatch={patch}
                  onRemove={remove}
                />
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="xl:sticky xl:top-6 xl:h-fit">
        <PhoneFrame>
          <CreatorPage profile={profile} links={rows} socials={socials} mode="preview" />
        </PhoneFrame>
      </div>
    </div>
  );
}

function RowCard({
  row,
  index,
  total,
  busy,
  onMove,
  onPatch,
  onRemove,
}: {
  row: PageLink;
  index: number;
  total: number;
  busy: boolean;
  onMove: (from: number, to: number) => void;
  onPatch: (id: string, values: Partial<PageLink>) => void;
  onRemove: (id: string) => void;
}) {
  const [title, setTitle] = useState(row.title);
  const [url, setUrl] = useState(row.url ?? "");
  const [confirming, setConfirming] = useState(false);

  // Follow the saved values, but only when they actually change -- comparing the whole row
  // would discard a half-typed title every time some other field on it was saved.
  const [savedTitle, setSavedTitle] = useState(row.title);
  if (savedTitle !== row.title) {
    setSavedTitle(row.title);
    setTitle(row.title);
  }

  const savedUrlValue = row.url ?? "";
  const [savedUrl, setSavedUrl] = useState(savedUrlValue);
  if (savedUrl !== savedUrlValue) {
    setSavedUrl(savedUrlValue);
    setUrl(savedUrlValue);
  }

  const icon = isIconKey(row.icon) ? row.icon : iconForUrl(row.url ?? "");
  const canPlay = row.kind === "embed" && row.platform !== "instagram";

  return (
    <Card className={cn("flex flex-col gap-2", !row.is_visible && "opacity-60")}>
      <div className="flex items-start gap-2">
        <div className="flex flex-col items-center gap-0.5 pt-1">
          <span className="cursor-grab text-ink-300 select-none" title="Drag to reorder">
            ⠿
          </span>
          <button
            type="button"
            onClick={() => onMove(index, index - 1)}
            disabled={index === 0 || busy}
            aria-label="Move up"
            className="text-xs text-ink-400 hover:text-ink-800 disabled:opacity-30"
          >
            ▲
          </button>
          <button
            type="button"
            onClick={() => onMove(index, index + 1)}
            disabled={index === total - 1 || busy}
            aria-label="Move down"
            className="text-xs text-ink-400 hover:text-ink-800 disabled:opacity-30"
          >
            ▼
          </button>
        </div>

        <div className="flex min-w-0 flex-1 flex-col gap-2">
          <div className="flex items-center gap-2">
            {row.kind === "header" ? (
              <span className="shrink-0 rounded bg-ink-100 px-1.5 py-0.5 text-[11px] text-ink-500">
                section
              </span>
            ) : (
              <SocialIcon name={icon} className="size-4 shrink-0 text-ink-400" />
            )}
            <Input
              aria-label="Title"
              value={title}
              maxLength={80}
              onChange={(event) => setTitle(event.target.value)}
              onBlur={() => title !== row.title && onPatch(row.id, { title })}
              className="py-1.5"
            />
          </div>

          {row.kind !== "header" && (
            <Input
              aria-label="URL"
              value={url}
              onChange={(event) => setUrl(event.target.value)}
              onBlur={() => url && url !== row.url && onPatch(row.id, { url })}
              className="py-1.5 text-xs text-ink-500"
            />
          )}

          {canPlay && (
            <label className="flex items-center gap-2 text-xs text-ink-500">
              <input
                type="checkbox"
                checked={row.embed_mode === "player"}
                onChange={(event) =>
                  onPatch(row.id, { embed_mode: event.target.checked ? "player" : "card" })
                }
              />
              Play on the page
            </label>
          )}
        </div>

        <div className="flex shrink-0 flex-col items-end gap-1">
          <button
            type="button"
            onClick={() => onPatch(row.id, { is_visible: !row.is_visible })}
            disabled={busy}
            className="text-xs text-ink-500 hover:underline"
          >
            {row.is_visible ? "hide" : "show"}
          </button>

          {confirming ? (
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => onRemove(row.id)}
                className="text-xs font-medium text-red-600 hover:underline"
              >
                delete
              </button>
              <button
                type="button"
                onClick={() => setConfirming(false)}
                className="text-xs text-ink-400 hover:underline"
              >
                keep
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirming(true)}
              className="text-xs text-ink-400 hover:text-red-600"
            >
              remove
            </button>
          )}
        </div>
      </div>
    </Card>
  );
}
