"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { detectEmbed, iconForUrl, normaliseUrl, titleFromUrl } from "@/lib/links";

type Result = { error?: string };

/**
 * Every write a creator makes to their own page.
 *
 * Row ownership is enforced by row level security, not by these functions -- each one
 * filters on the creator anyway, so a wrong id fails as "not found" rather than touching
 * somebody else's row, but the policy is what makes that guaranteed rather than careful.
 */

async function refresh(handle: string) {
  revalidatePath("/editor");
  revalidatePath("/appearance");
  revalidatePath(`/@${handle}`);
}

const titleSchema = z.string().trim().max(80);

export async function addLink(rawTitle: string, rawUrl: string): Promise<Result> {
  const profile = await requireProfile();

  const title = titleSchema.safeParse(rawTitle);
  if (!title.success) return { error: "Keep the title under 80 characters." };

  const url = normaliseUrl(rawUrl);
  if (!url) return { error: "That does not look like a link." };

  const supabase = await createClient();
  const { error } = await supabase.from("links").insert({
    profile_id: profile.id,
    kind: "link",
    title: title.data || titleFromUrl(url),
    url,
    icon: iconForUrl(url),
    position: await nextPosition(profile.id),
  });

  if (error) return { error: error.message };
  await refresh(profile.handle);
  return {};
}

export async function addHeader(rawTitle: string): Promise<Result> {
  const profile = await requireProfile();

  const title = titleSchema.safeParse(rawTitle);
  if (!title.success || !title.data) return { error: "Give the section a name." };

  const supabase = await createClient();
  const { error } = await supabase.from("links").insert({
    profile_id: profile.id,
    kind: "header",
    title: title.data,
    position: await nextPosition(profile.id),
  });

  if (error) return { error: error.message };
  await refresh(profile.handle);
  return {};
}

/**
 * Adds a YouTube, Instagram or Spotify item.
 *
 * The platform and the id are read out of the pasted URL rather than asked for, and an
 * unrecognised URL is added as an ordinary link instead of refused -- the creator pasted
 * something they want on their page either way.
 */
export async function addEmbed(rawUrl: string, rawTitle: string): Promise<Result> {
  const profile = await requireProfile();

  const url = normaliseUrl(rawUrl);
  if (!url) return { error: "That does not look like a link." };

  const embed = detectEmbed(url);
  if (!embed) {
    return addLink(rawTitle, rawUrl);
  }

  const title = titleSchema.safeParse(rawTitle);
  if (!title.success) return { error: "Keep the title under 80 characters." };

  const supabase = await createClient();
  const { error } = await supabase.from("links").insert({
    profile_id: profile.id,
    kind: "embed",
    title: title.data || `${embed.platform.charAt(0).toUpperCase()}${embed.platform.slice(1)}`,
    url,
    platform: embed.platform,
    external_id: embed.externalId,
    thumbnail_url: embed.thumbnail,
    embed_mode: embed.mode,
    icon: embed.platform,
    position: await nextPosition(profile.id),
  });

  if (error) return { error: error.message };
  await refresh(profile.handle);
  return {};
}

const patchSchema = z.object({
  title: titleSchema.optional(),
  url: z.string().trim().optional(),
  embed_mode: z.enum(["card", "player"]).optional(),
  is_visible: z.boolean().optional(),
});

export async function saveLink(id: string, patch: z.input<typeof patchSchema>): Promise<Result> {
  const profile = await requireProfile();

  const parsed = patchSchema.safeParse(patch);
  if (!parsed.success) return { error: "Those values are not valid." };

  const values: Record<string, unknown> = {};
  if (parsed.data.title !== undefined) values.title = parsed.data.title;
  if (parsed.data.is_visible !== undefined) values.is_visible = parsed.data.is_visible;
  if (parsed.data.embed_mode !== undefined) values.embed_mode = parsed.data.embed_mode;

  if (parsed.data.url !== undefined) {
    const url = normaliseUrl(parsed.data.url);
    if (!url) return { error: "That does not look like a link." };
    values.url = url;

    // Re-read the platform: a creator who swaps a YouTube URL for a Spotify one on the same
    // row should get a Spotify embed, not a YouTube player pointing at nothing.
    const embed = detectEmbed(url);
    if (embed) {
      values.platform = embed.platform;
      values.external_id = embed.externalId;
      values.thumbnail_url = embed.thumbnail;
      values.icon = embed.platform;
    } else {
      values.icon = iconForUrl(url);
    }
  }

  if (Object.keys(values).length === 0) return {};

  const supabase = await createClient();
  const { error } = await supabase
    .from("links")
    .update(values)
    .eq("id", id)
    .eq("profile_id", profile.id);

  if (error) return { error: error.message };
  await refresh(profile.handle);
  return {};
}

export async function deleteLink(id: string): Promise<Result> {
  const profile = await requireProfile();
  const supabase = await createClient();

  const { error } = await supabase
    .from("links")
    .delete()
    .eq("id", id)
    .eq("profile_id", profile.id);

  if (error) return { error: error.message };
  await refresh(profile.handle);
  return {};
}

export async function reorder(ids: string[]): Promise<Result> {
  const profile = await requireProfile();

  const parsed = z.array(z.string().uuid()).min(1).max(500).safeParse(ids);
  if (!parsed.success) return { error: "That order could not be saved." };

  const supabase = await createClient();
  const { error } = await supabase.rpc("reorder_links", { p_ids: parsed.data });

  if (error) return { error: error.message };
  await refresh(profile.handle);
  return {};
}

/** Puts a new row at the bottom, where the creator is looking when they add one. */
async function nextPosition(profileId: string): Promise<number> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("links")
    .select("position")
    .eq("profile_id", profileId)
    .order("position", { ascending: false })
    .limit(1)
    .maybeSingle();

  return (data?.position ?? 0) + 1;
}
