import Link from "next/link";
import { requireProfile } from "@/lib/auth";
import { siteUrl } from "@/lib/env";
import { CopyLink } from "@/components/copy-link";
import { NavLink } from "@/components/nav-link";
import { SignOut } from "@/components/sign-out";
import { Pill } from "@/components/ui";

const NAV = [
  { href: "/editor", label: "Links" },
  { href: "/appearance", label: "Appearance" },
  { href: "/analytics", label: "Analytics" },
  { href: "/settings", label: "Settings" },
];

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const profile = await requireProfile();
  const url = `${siteUrl()}/@${profile.handle}`;

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-6xl flex-col gap-6 px-5 py-6 lg:flex-row">
      <aside className="flex shrink-0 flex-col gap-4 lg:w-56">
        <Link href="/editor" className="text-sm font-semibold text-ink-900">
          Link in Bio
        </Link>

        <div className="flex flex-col gap-2">
          <CopyLink url={url} />
          <div className="flex items-center gap-2 px-1">
            {profile.is_published ? (
              <Pill tone="good">live</Pill>
            ) : (
              <Pill tone="warn">not published</Pill>
            )}
            <a
              href={`/@${profile.handle}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-ink-500 hover:underline"
            >
              view page
            </a>
          </div>
        </div>

        <nav className="flex gap-1 overflow-x-auto lg:flex-col lg:overflow-visible">
          {NAV.map((item) => (
            <NavLink key={item.href} href={item.href}>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="mt-auto hidden lg:block">
          <SignOut />
        </div>
      </aside>

      <main className="min-w-0 flex-1">{children}</main>

      <div className="lg:hidden">
        <SignOut />
      </div>
    </div>
  );
}
