"use client";

import Image from "next/image";
import { useEffect, useRef, useState, useTransition } from "react";
import { createClient } from "@/lib/supabase/client";
import {
  BUTTON_STYLES,
  FONTS,
  PRESETS,
  RADII,
  resolveTheme,
  type ButtonStyle,
  type FontKey,
  type RadiusKey,
  type Theme,
} from "@/lib/theme";
import { SOCIAL_PLATFORMS, type SocialPlatform } from "@/lib/links";
import { Alert, Button, Card, Field, Input, Select, Textarea, cn } from "@/components/ui";
import { CreatorPage } from "@/components/creator-page";
import { PhoneFrame } from "@/components/phone-frame";
import { SocialIcon, isIconKey } from "@/components/social-icon";
import type { PageLink, Profile, Social } from "@/lib/types";
import { deleteSocial, saveProfile, saveSocial, saveTheme } from "./actions";

const MAX_AVATAR_BYTES = 2 * 1024 * 1024;
// A banner is wide where a photo is small, so it gets the larger allowance.
const MAX_BANNER_BYTES = 4 * 1024 * 1024;

export function AppearanceWorkspace({
  profile,
  links,
  socials,
}: {
  profile: Profile;
  links: PageLink[];
  socials: Social[];
}) {
  const [name, setName] = useState(profile.display_name);
  const [bio, setBio] = useState(profile.bio ?? "");
  const [avatar, setAvatar] = useState(profile.avatar_url);
  const [banner, setBanner] = useState(profile.banner_url);
  const [theme, setTheme] = useState<Theme>(profile.theme);
  const [platform, setPlatform] = useState<SocialPlatform>("instagram");
  const [socialValue, setSocialValue] = useState("");
  const [message, setMessage] = useState<{ tone: "good" | "bad"; text: string } | null>(null);
  const [themeSaving, setThemeSaving] = useState(false);
  const [pending, start] = useTransition();
  const fileInput = useRef<HTMLInputElement>(null);
  const bannerInput = useRef<HTMLInputElement>(null);
  const themeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  function run(action: () => Promise<{ error?: string }>, done?: string) {
    start(async () => {
      const result = await action();
      setMessage(
        result.error
          ? { tone: "bad", text: result.error }
          : done
            ? { tone: "good", text: done }
            : null,
      );
    });
  }

  /**
   * The theme is saved as it is changed rather than behind a button, but not on every
   * change.
   *
   * A colour input fires while the picker is being dragged, so saving on each one queued
   * dozens of writes: React runs them one after another, so the whole panel sat disabled
   * behind a "Saving..." that never finished. The preview still moves with the mouse; only
   * the write waits for the creator to settle.
   *
   * Its own flag rather than the shared transition, so a theme write never disables the
   * profile form or the social icons beside it.
   */
  function applyTheme(next: Theme) {
    setTheme(next);
    setThemeSaving(true);

    if (themeTimer.current) clearTimeout(themeTimer.current);
    themeTimer.current = setTimeout(async () => {
      const result = await saveTheme(next);
      setThemeSaving(false);
      if (result.error) setMessage({ tone: "bad", text: result.error });
    }, 500);
  }

  // A theme change still in the timer when the creator leaves would never be written.
  useEffect(() => {
    return () => {
      if (themeTimer.current) clearTimeout(themeTimer.current);
    };
  }, []);

  async function upload(file: File, kind: "avatar" | "banner") {
    const limit = kind === "banner" ? MAX_BANNER_BYTES : MAX_AVATAR_BYTES;
    if (file.size > limit) {
      setMessage({
        tone: "bad",
        text: `${kind === "banner" ? "Banners" : "Pictures"} need to be under ${
          limit / 1024 / 1024
        }MB.`,
      });
      return;
    }

    const supabase = createClient();
    const extension = file.name.split(".").pop()?.toLowerCase() ?? "jpg";
    // The creator's own id is the first path segment, which is exactly what the storage
    // policy checks -- so a creator can only ever write inside their own folder.
    const path = `${profile.id}/${kind}-${crypto.randomUUID()}.${extension}`;

    const { error } = await supabase.storage
      .from("avatars")
      .upload(path, file, { upsert: true, contentType: file.type });

    if (error) {
      setMessage({ tone: "bad", text: error.message });
      return;
    }

    const {
      data: { publicUrl },
    } = supabase.storage.from("avatars").getPublicUrl(path);

    if (kind === "banner") {
      setBanner(publicUrl);
      run(
        () => saveProfile({ display_name: name, bio, banner_url: publicUrl }),
        "Banner updated.",
      );
      return;
    }

    setAvatar(publicUrl);
    run(
      () => saveProfile({ display_name: name, bio, avatar_url: publicUrl }),
      "Picture updated.",
    );
  }

  const preview: Profile = {
    ...profile,
    display_name: name,
    bio,
    avatar_url: avatar,
    banner_url: banner,
    theme,
  };
  const resolved = resolveTheme(theme);

  return (
    <div className="flex flex-col gap-6 xl:flex-row">
      <div className="flex min-w-0 flex-1 flex-col gap-4">
        {message && <Alert tone={message.tone}>{message.text}</Alert>}

        <Card className="flex flex-col gap-4">
          <h2 className="text-sm font-semibold text-ink-800">Profile</h2>

          <div className="flex flex-col gap-2">
            <div className="relative h-24 w-full overflow-hidden rounded-lg border border-border bg-ink-50">
              {banner ? (
                <Image
                  src={banner}
                  alt=""
                  fill
                  unoptimized
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 480px"
                />
              ) : (
                <span className="flex h-full items-center justify-center text-xs text-ink-400">
                  No banner yet
                </span>
              )}
            </div>

            <div className="flex items-center gap-3">
              <input
                ref={bannerInput}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (file) void upload(file, "banner");
                  event.target.value = "";
                }}
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => bannerInput.current?.click()}
                disabled={pending}
              >
                {banner ? "Change banner" : "Add a banner"}
              </Button>
              {banner && (
                <button
                  type="button"
                  onClick={() => {
                    setBanner(null);
                    run(() => saveProfile({ display_name: name, bio, banner_url: "" }));
                  }}
                  className="text-xs text-ink-400 hover:text-red-600"
                >
                  remove
                </button>
              )}
              <span className="text-xs text-ink-400">Wide image, up to 4MB.</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {avatar ? (
              <Image
                src={avatar}
                alt=""
                width={64}
                height={64}
                unoptimized
                className="size-16 rounded-full object-cover"
              />
            ) : (
              <div className="flex size-16 items-center justify-center rounded-full bg-ink-100 text-lg font-semibold text-ink-500">
                {(name || profile.handle).slice(0, 1).toUpperCase()}
              </div>
            )}

            <div className="flex flex-col gap-1">
              <input
                ref={fileInput}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (file) void upload(file, "avatar");
                  event.target.value = "";
                }}
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => fileInput.current?.click()}
                disabled={pending}
              >
                {avatar ? "Change picture" : "Upload a picture"}
              </Button>
              {avatar && (
                <button
                  type="button"
                  onClick={() => {
                    setAvatar(null);
                    run(() => saveProfile({ display_name: name, bio, avatar_url: "" }));
                  }}
                  className="text-xs text-ink-400 hover:text-red-600"
                >
                  remove
                </button>
              )}
            </div>
          </div>

          <Field label="Display name" htmlFor="display_name">
            <Input
              id="display_name"
              value={name}
              maxLength={60}
              onChange={(event) => setName(event.target.value)}
            />
          </Field>

          <Field label="Bio" htmlFor="bio" hint={`${bio.length}/300`}>
            <Textarea
              id="bio"
              value={bio}
              maxLength={300}
              onChange={(event) => setBio(event.target.value)}
            />
          </Field>

          <div>
            <Button
              type="button"
              disabled={pending}
              onClick={() =>
                run(() => saveProfile({ display_name: name, bio }), "Profile saved.")
              }
            >
              {pending ? "Saving..." : "Save profile"}
            </Button>
          </div>
        </Card>

        <Card className="flex flex-col gap-4">
          <h2 className="text-sm font-semibold text-ink-800">Social icons</h2>

          {socials.length > 0 && (
            <ul className="flex flex-col gap-2">
              {socials.map((social) => (
                <li key={social.id} className="flex items-center gap-2">
                  <SocialIcon
                    name={isIconKey(social.platform) ? social.platform : "website"}
                    className="size-4 shrink-0 text-ink-400"
                  />
                  <span className="w-20 shrink-0 text-xs text-ink-500">
                    {SOCIAL_PLATFORMS[social.platform as SocialPlatform]?.label ??
                      social.platform}
                  </span>
                  <span className="min-w-0 flex-1 truncate text-xs text-ink-500">
                    {social.url}
                  </span>
                  <button
                    type="button"
                    onClick={() => run(() => deleteSocial(social.id))}
                    className="shrink-0 text-xs text-ink-400 hover:text-red-600"
                  >
                    remove
                  </button>
                </li>
              ))}
            </ul>
          )}

          <div className="flex flex-wrap gap-2">
            <Select
              aria-label="Platform"
              value={platform}
              onChange={(event) => setPlatform(event.target.value as SocialPlatform)}
              className="w-auto"
            >
              {Object.entries(SOCIAL_PLATFORMS).map(([key, value]) => (
                <option key={key} value={key}>
                  {value.label}
                </option>
              ))}
            </Select>
            <Input
              aria-label="Link"
              placeholder={SOCIAL_PLATFORMS[platform].hint}
              value={socialValue}
              onChange={(event) => setSocialValue(event.target.value)}
              className="min-w-52 flex-1"
            />
            <Button
              type="button"
              disabled={!socialValue.trim()}
              onClick={() => {
                const value = socialValue;
                setSocialValue("");
                run(() => saveSocial(platform, value));
              }}
            >
              Add
            </Button>
          </div>
        </Card>

        <Card className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink-800">Theme</h2>
            <span className="text-xs text-ink-400">{themeSaving ? "saving..." : "saved"}</span>
          </div>

          <ul className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {Object.entries(PRESETS).map(([key, preset]) => (
              <li key={key}>
                <button
                  type="button"
                  onClick={() => applyTheme({ preset: key })}
                  className={cn(
                    "w-full overflow-hidden rounded-lg border-2 p-2 text-left",
                    theme.preset === key ? "border-ink-900" : "border-border hover:border-ink-300",
                  )}
                >
                  <span
                    className="flex h-14 items-end rounded p-1.5"
                    style={{ background: preset.background }}
                  >
                    <span
                      className="block h-4 w-full rounded-sm"
                      style={{ background: preset.card }}
                    />
                  </span>
                  <span className="mt-1.5 block text-xs font-medium text-ink-600">
                    {preset.label}
                  </span>
                </button>
              </li>
            ))}
          </ul>

          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="Font" htmlFor="font">
              <Select
                id="font"
                value={resolved.font}
                onChange={(event) =>
                  applyTheme({ ...theme, font: event.target.value as FontKey })
                }
              >
                {Object.entries(FONTS).map(([key, value]) => (
                  <option key={key} value={key}>
                    {value.label}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="Corners" htmlFor="radius">
              <Select
                id="radius"
                value={resolved.radius}
                onChange={(event) =>
                  applyTheme({ ...theme, radius: event.target.value as RadiusKey })
                }
              >
                {Object.entries(RADII).map(([key, value]) => (
                  <option key={key} value={key}>
                    {value.label}
                  </option>
                ))}
              </Select>
            </Field>

            <Field label="Buttons" htmlFor="button">
              <Select
                id="button"
                value={resolved.button}
                onChange={(event) =>
                  applyTheme({ ...theme, button: event.target.value as ButtonStyle })
                }
              >
                {Object.entries(BUTTON_STYLES).map(([key, label]) => (
                  <option key={key} value={key}>
                    {label}
                  </option>
                ))}
              </Select>
            </Field>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <ColourField
              label="Text"
              value={resolved.text}
              onChange={(value) => applyTheme({ ...theme, text: value })}
            />
            <ColourField
              label="Buttons"
              value={resolved.card}
              onChange={(value) => applyTheme({ ...theme, card: value })}
            />
            <ColourField
              label="Button text"
              value={resolved.cardText}
              onChange={(value) => applyTheme({ ...theme, cardText: value })}
            />
          </div>

          {(theme.text || theme.card || theme.cardText || theme.background) && (
            <button
              type="button"
              onClick={() => applyTheme({ preset: theme.preset })}
              className="self-start text-xs text-ink-500 hover:underline"
            >
              Reset colours to the {PRESETS[theme.preset]?.label ?? "chosen"} theme
            </button>
          )}
        </Card>
      </div>

      <div className="xl:sticky xl:top-6 xl:h-fit">
        <PhoneFrame>
          <CreatorPage profile={preview} links={links} socials={socials} mode="preview" />
        </PhoneFrame>
      </div>
    </div>
  );
}

/**
 * A colour input with the hex beside it.
 *
 * The native picker is the only control that makes choosing a colour pleasant, but it gives
 * no way to paste a brand hex -- so both are here, and the text field only commits once it
 * holds a full six-digit value.
 */
function ColourField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  const [text, setText] = useState(value);

  // Follows the preset when the creator switches theme, but not while they are part way
  // through typing a hex: an incomplete value never reaches `value`, so this cannot fire.
  const [applied, setApplied] = useState(value);
  if (applied !== value) {
    setApplied(value);
    setText(value);
  }

  return (
    <Field label={label}>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={value}
          aria-label={label}
          onChange={(event) => {
            setText(event.target.value);
            onChange(event.target.value);
          }}
          className="size-9 shrink-0 cursor-pointer rounded border border-border bg-surface"
        />
        <Input
          value={text}
          onChange={(event) => {
            const next = event.target.value;
            setText(next);
            if (/^#[0-9a-fA-F]{6}$/.test(next)) onChange(next);
          }}
          className="py-1.5 font-mono text-xs"
        />
      </div>
    </Field>
  );
}
