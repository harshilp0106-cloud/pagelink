"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { normaliseUrl } from "@/lib/links";
import { PRESETS, themeSchema } from "@/lib/theme";
import { SOCIAL_PLATFORMS } from "@/lib/links";

type Result = { error?: string };

async function refresh(handle: string) {
  revalidatePath("/appearance");
  revalidatePath("/editor");
  revalidatePath(`/@${handle}`);
}

const profileSchema = z.object({
  display_name: z.string().trim().max(60),
  bio: z.string().trim().max(300),
  avatar_url: z.string().trim().url().or(z.literal("")).optional(),
  banner_url: z.string().trim().url().or(z.literal("")).optional(),
});

export async function saveProfile(input: z.input<typeof profileSchema>): Promise<Result> {
  const profile = await requireProfile();

  const parsed = profileSchema.safeParse(input);
  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Those details are not valid." };
  }

  const supabase = await createClient();
  const { error } = await supabase
    .from("profiles")
    .update({
      display_name: parsed.data.display_name,
      bio: parsed.data.bio || null,
      // Left out rather than nulled when absent: the banner is saved from its own button,
      // and a save from the name and bio form must not clear the images.
      ...(parsed.data.avatar_url === undefined
        ? {}
        : { avatar_url: parsed.data.avatar_url || null }),
      ...(parsed.data.banner_url === undefined
        ? {}
        : { banner_url: parsed.data.banner_url || null }),
    })
    .eq("id", profile.id);

  if (error) return { error: error.message };
  await refresh(profile.handle);
  return {};
}

/**
 * Saves the look.
 *
 * The preset has to be one this build knows about, and each colour is checked against the
 * theme schema's own grammar -- these values are written into a style attribute on a public
 * page, so "whatever CSS the browser accepts" is not a safe answer.
 */
export async function saveTheme(input: unknown): Promise<Result> {
  const profile = await requireProfile();

  const parsed = themeSchema.safeParse(input);
  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "That theme is not valid." };
  }
  if (!PRESETS[parsed.data.preset]) return { error: "Pick one of the themes." };

  const supabase = await createClient();
  const { error } = await supabase
    .from("profiles")
    .update({ theme: parsed.data })
    .eq("id", profile.id);

  if (error) return { error: error.message };
  await refresh(profile.handle);
  return {};
}

const platform = z.enum(
  Object.keys(SOCIAL_PLATFORMS) as [keyof typeof SOCIAL_PLATFORMS, ...Array<keyof typeof SOCIAL_PLATFORMS>],
);

/**
 * Adds or replaces one social icon.
 *
 * One row per platform, so adding Instagram twice updates it rather than putting two
 * identical icons in the row -- which is what the unique constraint on the table says too.
 */
export async function saveSocial(rawPlatform: string, rawValue: string): Promise<Result> {
  const profile = await requireProfile();

  const parsed = platform.safeParse(rawPlatform);
  if (!parsed.success) return { error: "Unknown platform." };

  const value = rawValue.trim();
  if (!value) return { error: "Add the link first." };

  // An email address is what a creator will type for the email icon; turn it into a link
  // rather than telling them off about the missing mailto:.
  const candidate =
    parsed.data === "email" && !value.startsWith("mailto:") && value.includes("@")
      ? `mailto:${value}`
      : value;

  const url = normaliseUrl(candidate);
  if (!url) return { error: "That does not look like a link." };

  const supabase = await createClient();
  const { data: existing } = await supabase
    .from("socials")
    .select("position")
    .eq("profile_id", profile.id)
    .order("position", { ascending: false })
    .limit(1)
    .maybeSingle();

  const { error } = await supabase.from("socials").upsert(
    {
      profile_id: profile.id,
      platform: parsed.data,
      url,
      position: (existing?.position ?? 0) + 1,
    },
    { onConflict: "profile_id,platform" },
  );

  if (error) return { error: error.message };
  await refresh(profile.handle);
  return {};
}

export async function deleteSocial(id: string): Promise<Result> {
  const profile = await requireProfile();
  const supabase = await createClient();

  const { error } = await supabase
    .from("socials")
    .delete()
    .eq("id", id)
    .eq("profile_id", profile.id);

  if (error) return { error: error.message };
  await refresh(profile.handle);
  return {};
}
