import Link from "next/link";
import { requireProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { Card, Empty, PageHeader, cn } from "@/components/ui";
import type { DailyTraffic, LinkPerformance } from "@/lib/types";

const RANGES = [
  { days: 7, label: "7 days" },
  { days: 30, label: "30 days" },
  { days: 90, label: "90 days" },
];

/**
 * What the page is actually doing.
 *
 * Both figures are counted server side -- views when the page renders, clicks when the
 * redirect route runs -- so nothing here depends on a visitor's browser running our script
 * or on their ad blocker letting it.
 */
export default async function AnalyticsPage({
  searchParams,
}: {
  searchParams: Promise<{ days?: string }>;
}) {
  const profile = await requireProfile();
  const { days: rawDays } = await searchParams;

  const days = RANGES.some((range) => String(range.days) === rawDays) ? Number(rawDays) : 30;

  const supabase = await createClient();
  // Cast rather than `.returns<T[]>()`: without generated database types, supabase-js types
  // every rpc as returning a single object, and a set-returning function then reads as a
  // type mismatch rather than as the array it actually is.
  const [{ data: traffic }, { data: performance }] = await Promise.all([
    supabase.rpc("daily_traffic", { p_days: days }),
    supabase.rpc("link_performance", { p_days: days }),
  ]);

  const series = (traffic ?? []) as DailyTraffic[];
  const rows = (performance ?? []) as LinkPerformance[];
  const views = series.reduce((total, day) => total + Number(day.views), 0);
  const clicks = series.reduce((total, day) => total + Number(day.clicks), 0);
  const peak = Math.max(1, ...series.map((day) => Math.max(Number(day.views), Number(day.clicks))));

  return (
    <div className="flex flex-col gap-5">
      <PageHeader
        title="Analytics"
        subtitle={profile.is_published ? undefined : "Your page is not published yet."}
        action={
          <div className="flex gap-1">
            {RANGES.map((range) => (
              <Link
                key={range.days}
                href={`/analytics?days=${range.days}`}
                className={cn(
                  "rounded-lg px-3 py-1.5 text-xs font-medium",
                  range.days === days
                    ? "bg-ink-900 text-white"
                    : "border border-border text-ink-600 hover:bg-ink-50",
                )}
              >
                {range.label}
              </Link>
            ))}
          </div>
        }
      />

      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Page views" value={views} />
        <Stat label="Link clicks" value={clicks} />
        <Stat
          label="Clicks per view"
          value={views ? `${Math.round((clicks / views) * 100)}%` : "--"}
        />
      </div>

      <Card className="flex flex-col gap-3">
        <h2 className="text-sm font-semibold text-ink-800">Day by day</h2>

        <div className="flex items-end gap-1 overflow-x-auto pb-1">
          {series.map((day) => (
            <div key={day.day} className="flex min-w-3 flex-1 flex-col items-center gap-1">
              <div
                className="flex w-full items-end justify-center gap-0.5"
                style={{ height: 120 }}
                title={`${day.day}: ${day.views} views, ${day.clicks} clicks`}
              >
                <span
                  className="w-1/2 rounded-t bg-ink-300"
                  style={{ height: `${(Number(day.views) / peak) * 100}%` }}
                />
                <span
                  className="w-1/2 rounded-t bg-ink-900"
                  style={{ height: `${(Number(day.clicks) / peak) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between text-xs text-ink-400">
          <span>{series[0]?.day}</span>
          <span className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <span className="size-2 rounded-sm bg-ink-300" /> views
            </span>
            <span className="flex items-center gap-1">
              <span className="size-2 rounded-sm bg-ink-900" /> clicks
            </span>
          </span>
          <span>{series[series.length - 1]?.day}</span>
        </div>
      </Card>

      <Card className="flex flex-col gap-3">
        <h2 className="text-sm font-semibold text-ink-800">Clicks per link</h2>

        {rows.length === 0 ? (
          <Empty
            title="No links yet"
            body="Add a link and its clicks show up here from the moment somebody uses it."
          />
        ) : (
          <ul className="flex flex-col divide-y divide-border">
            {rows.map((row) => (
              <li key={row.link_id} className="flex items-center gap-3 py-2.5 first:pt-0">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-ink-800">
                    {row.title || "Untitled"}
                  </p>
                  {row.url && <p className="truncate text-xs text-ink-400">{row.url}</p>}
                </div>
                <div className="flex w-40 shrink-0 items-center gap-2">
                  <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-ink-100">
                    <span
                      className="block h-full rounded-full bg-ink-900"
                      style={{
                        width: `${Math.round(
                          (Number(row.clicks) / Math.max(1, Number(rows[0].clicks))) * 100,
                        )}%`,
                      }}
                    />
                  </span>
                  <span className="w-8 text-right text-sm text-ink-600">{row.clicks}</span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <Card>
      <p className="text-xs text-ink-500">{label}</p>
      <p className="mt-1 text-2xl font-semibold text-ink-900">
        {typeof value === "number" ? value.toLocaleString("en-IN") : value}
      </p>
    </Card>
  );
}
