import Link from "next/link";
import { redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import { Button } from "@/components/ui";

/**
 * The front door.
 *
 * A signed-in creator never wants to see it -- they came here to edit their page -- so they
 * are sent straight to the editor.
 *
 * It also catches an auth code that lands here instead of on the callback. Supabase falls
 * back to the project's site URL when an emailed link's redirect is not on its allow-list,
 * and a code sitting on the home page would otherwise be a dead link in somebody's inbox.
 */
export default async function Home({
  searchParams,
}: {
  searchParams: Promise<{ code?: string; next?: string }>;
}) {
  const { code, next } = await searchParams;
  if (code) {
    const target = next && next.startsWith("/") && !next.startsWith("//") ? next : "/editor";
    redirect(`/auth/callback?code=${encodeURIComponent(code)}&next=${encodeURIComponent(target)}`);
  }

  const user = await currentUser();
  if (user) redirect("/editor");

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-lg flex-col justify-center gap-8 px-6 py-16">
      <div className="flex flex-col gap-3">
        <p className="text-sm font-semibold text-ink-900">Link in Bio</p>
        <h1 className="text-3xl font-semibold tracking-tight text-ink-900 sm:text-4xl">
          One link for everything you share.
        </h1>
        <p className="text-base text-ink-500">
          Put your shop, your latest video and every profile behind a single address, and see
          which of them people actually open.
        </p>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Link href="/signup">
          <Button>Create your page</Button>
        </Link>
        <Link href="/login">
          <Button variant="outline">Sign in</Button>
        </Link>
      </div>

      <ul className="flex flex-col gap-2 text-sm text-ink-500">
        <li>Links, section titles, and YouTube or Spotify that plays on the page.</li>
        <li>Eight themes, or your own colours and fonts.</li>
        <li>Views and clicks per link, over any date range.</li>
      </ul>
    </main>
  );
}
