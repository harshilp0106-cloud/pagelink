import type { NextRequest } from "next/server";
import { updateSession } from "@/lib/supabase/session";

/**
 * Next 16 renamed the middleware convention to proxy; the behaviour is unchanged. This
 * keeps the Supabase auth cookie fresh and guards the editor.
 */
export function proxy(request: NextRequest) {
  return updateSession(request);
}

export const config = {
  matcher: [
    /*
     * Everything except static assets and the routes that authenticate themselves. The
     * public creator pages are deliberately included: they do not need a session, but they
     * do benefit from the cookie refresh when the creator is previewing their own page.
     */
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico)$).*)",
  ],
};
