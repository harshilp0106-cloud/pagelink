import type { Theme } from "@/lib/theme";

/** A creator and everything that decorates their page. */
export type Profile = {
  id: string;
  handle: string;
  display_name: string;
  bio: string | null;
  avatar_url: string | null;
  banner_url: string | null;
  theme: Theme;
  is_published: boolean;
  created_at: string;
  updated_at: string;
};

export type LinkKind = "link" | "header" | "embed";
export type EmbedMode = "card" | "player";

/**
 * One row of a creator's page.
 *
 * Links, section headers and embeds share this shape because they share an order, and the
 * creator drags them around in a single list. `kind` decides which of the fields matter.
 */
export type PageLink = {
  id: string;
  profile_id: string;
  kind: LinkKind;
  title: string;
  url: string | null;
  icon: string | null;
  platform: string | null;
  external_id: string | null;
  thumbnail_url: string | null;
  embed_mode: EmbedMode;
  position: number;
  is_visible: boolean;
  created_at: string;
};

export type Social = {
  id: string;
  profile_id: string;
  platform: string;
  url: string;
  position: number;
};

export type DailyTraffic = { day: string; views: number; clicks: number };

export type LinkPerformance = {
  link_id: string;
  title: string;
  url: string | null;
  clicks: number;
};
