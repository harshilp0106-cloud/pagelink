import type { EmbedMode } from "@/lib/types";

/**
 * Everything the product knows about a pasted URL.
 *
 * Creators paste, they do not fill in forms: a YouTube link should become a YouTube embed
 * and an Instagram profile should pick up the Instagram icon without anyone choosing
 * either from a menu.
 */

/** Adds a scheme if the creator left it off, and rejects anything that is not a web link. */
export function normaliseUrl(raw: string): string | null {
  const trimmed = raw.trim();
  if (!trimmed) return null;

  const withScheme = /^[a-z][a-z0-9+.-]*:/i.test(trimmed) ? trimmed : `https://${trimmed}`;

  let parsed: URL;
  try {
    parsed = new URL(withScheme);
  } catch {
    return null;
  }

  // mailto: and tel: are genuinely useful on a link-in-bio page. Everything else with a
  // scheme -- javascript:, data:, file: -- is either an attack or a mistake.
  if (parsed.protocol === "mailto:" || parsed.protocol === "tel:") return parsed.href;
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
  if (!parsed.hostname.includes(".")) return null;

  parsed.protocol = "https:";
  return parsed.href;
}

export function hostOf(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "").toLowerCase();
  } catch {
    return "";
  }
}

export const SOCIAL_PLATFORMS = {
  instagram: { label: "Instagram", hint: "instagram.com/yourname" },
  youtube: { label: "YouTube", hint: "youtube.com/@yourname" },
  tiktok: { label: "TikTok", hint: "tiktok.com/@yourname" },
  x: { label: "X", hint: "x.com/yourname" },
  facebook: { label: "Facebook", hint: "facebook.com/yourpage" },
  linkedin: { label: "LinkedIn", hint: "linkedin.com/in/yourname" },
  spotify: { label: "Spotify", hint: "open.spotify.com/artist/..." },
  pinterest: { label: "Pinterest", hint: "pinterest.com/yourname" },
  whatsapp: { label: "WhatsApp", hint: "wa.me/919876543210" },
  email: { label: "Email", hint: "you@example.com" },
  website: { label: "Website", hint: "yoursite.com" },
} as const;

export type SocialPlatform = keyof typeof SOCIAL_PLATFORMS;

const HOST_ICONS: Array<[RegExp, SocialPlatform]> = [
  [/(^|\.)instagram\.com$/, "instagram"],
  [/(^|\.)(youtube\.com|youtu\.be)$/, "youtube"],
  [/(^|\.)tiktok\.com$/, "tiktok"],
  [/(^|\.)(twitter\.com|x\.com)$/, "x"],
  [/(^|\.)(facebook\.com|fb\.com)$/, "facebook"],
  [/(^|\.)linkedin\.com$/, "linkedin"],
  [/(^|\.)spotify\.com$/, "spotify"],
  [/(^|\.)pinterest\.(com|[a-z]{2})$/, "pinterest"],
  [/(^|\.)(wa\.me|whatsapp\.com)$/, "whatsapp"],
];

/** The icon a link gets when the creator does not pick one. */
export function iconForUrl(url: string): SocialPlatform {
  if (url.startsWith("mailto:")) return "email";
  const host = hostOf(url);
  for (const [pattern, icon] of HOST_ICONS) {
    if (pattern.test(host)) return icon;
  }
  return "website";
}

export type EmbedInfo = {
  platform: "youtube" | "instagram" | "spotify";
  externalId: string;
  mode: EmbedMode;
  thumbnail: string | null;
};

/**
 * Reads an embeddable id out of a pasted URL.
 *
 * Instagram comes back as a card, never a player. Its own embed script runs client-side and
 * fails often enough to leave a hole in the page, and a thumbnail through oEmbed now needs a
 * Facebook app and a token the client does not have. A card that links out always works.
 */
export function detectEmbed(url: string): EmbedInfo | null {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }

  const host = parsed.hostname.replace(/^www\./, "").toLowerCase();
  const parts = parsed.pathname.split("/").filter(Boolean);

  if (host === "youtu.be" && parts[0]) {
    return youtube(parts[0]);
  }
  if (host === "youtube.com" || host === "m.youtube.com" || host === "music.youtube.com") {
    const v = parsed.searchParams.get("v");
    if (v) return youtube(v);
    if ((parts[0] === "shorts" || parts[0] === "embed" || parts[0] === "live") && parts[1]) {
      return youtube(parts[1]);
    }
    return null;
  }

  if (host === "instagram.com") {
    const kind = parts[0];
    if ((kind === "p" || kind === "reel" || kind === "reels" || kind === "tv") && parts[1]) {
      return {
        platform: "instagram",
        externalId: `${kind === "reels" ? "reel" : kind}/${parts[1]}`,
        mode: "card",
        thumbnail: null,
      };
    }
    return null;
  }

  if (host === "open.spotify.com") {
    const kind = parts[0];
    const allowed = ["track", "album", "playlist", "episode", "show", "artist"];
    if (kind && allowed.includes(kind) && parts[1]) {
      return {
        platform: "spotify",
        externalId: `${kind}/${parts[1]}`,
        mode: "player",
        thumbnail: null,
      };
    }
    return null;
  }

  return null;
}

function youtube(id: string): EmbedInfo | null {
  if (!/^[\w-]{6,20}$/.test(id)) return null;
  return {
    platform: "youtube",
    externalId: id,
    mode: "player",
    // YouTube serves this without a key or a token, which is the whole reason a YouTube
    // card can show artwork and an Instagram card cannot.
    thumbnail: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
  };
}

/** The iframe source for an embed the creator asked to play inline. */
export function playerSrc(platform: string, externalId: string): string | null {
  if (platform === "youtube") {
    return `https://www.youtube-nocookie.com/embed/${encodeURIComponent(externalId)}`;
  }
  if (platform === "spotify") {
    const [kind, id] = externalId.split("/");
    if (!kind || !id) return null;
    return `https://open.spotify.com/embed/${encodeURIComponent(kind)}/${encodeURIComponent(id)}`;
  }
  return null;
}

/** A readable fallback title, so a pasted link is never left as an untitled row. */
export function titleFromUrl(url: string): string {
  if (url.startsWith("mailto:")) return "Email me";
  if (url.startsWith("tel:")) return "Call me";

  const host = hostOf(url);
  if (!host) return "Link";

  const label = host.split(".")[0];
  return label.charAt(0).toUpperCase() + label.slice(1);
}
