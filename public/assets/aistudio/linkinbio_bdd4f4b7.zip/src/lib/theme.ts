import { z } from "zod";
import type { CSSProperties } from "react";

/**
 * A creator's look, stored as a preset name plus whatever they changed.
 *
 * Storing the overrides rather than a full copy of the preset means a preset can be
 * improved later and every page that never touched its colours picks the improvement up.
 * It also keeps the row small: most creators pick a preset and stop.
 */

export const FONTS = {
  sans: { label: "Sans", stack: "var(--font-sans)" },
  display: { label: "Display", stack: "var(--font-display)" },
  serif: { label: "Serif", stack: "var(--font-serif)" },
  mono: { label: "Mono", stack: "var(--font-mono)" },
} as const;

export type FontKey = keyof typeof FONTS;

export const RADII = {
  sharp: { label: "Sharp", value: "0.25rem" },
  soft: { label: "Soft", value: "0.875rem" },
  round: { label: "Round", value: "999px" },
} as const;

export type RadiusKey = keyof typeof RADII;

export const BUTTON_STYLES = {
  fill: "Filled",
  outline: "Outline",
  soft: "Soft",
} as const;

export type ButtonStyle = keyof typeof BUTTON_STYLES;

export type Preset = {
  label: string;
  background: string;
  text: string;
  card: string;
  cardText: string;
  accent: string;
  font: FontKey;
  radius: RadiusKey;
  button: ButtonStyle;
};

export const PRESETS: Record<string, Preset> = {
  midnight: {
    label: "Midnight",
    background: "linear-gradient(180deg, #101322 0%, #1b2036 100%)",
    text: "#f4f5fb",
    card: "#242b45",
    cardText: "#f4f5fb",
    accent: "#8ea2ff",
    font: "sans",
    radius: "soft",
    button: "fill",
  },
  paper: {
    label: "Paper",
    background: "#f6f4ef",
    text: "#22201c",
    card: "#ffffff",
    cardText: "#22201c",
    accent: "#b4552d",
    font: "serif",
    radius: "sharp",
    button: "outline",
  },
  sunrise: {
    label: "Sunrise",
    background: "linear-gradient(180deg, #ff9a6c 0%, #ffd9a0 100%)",
    text: "#3d1b0c",
    card: "#ffffff",
    cardText: "#3d1b0c",
    accent: "#e2582a",
    font: "display",
    radius: "round",
    button: "fill",
  },
  mint: {
    label: "Mint",
    background: "linear-gradient(180deg, #e7fbf3 0%, #cfeee6 100%)",
    text: "#123a30",
    card: "#ffffff",
    cardText: "#123a30",
    accent: "#128a68",
    font: "sans",
    radius: "soft",
    button: "soft",
  },
  blush: {
    label: "Blush",
    background: "linear-gradient(180deg, #fdeef3 0%, #f7d9e6 100%)",
    text: "#4a1d31",
    card: "#ffffff",
    cardText: "#4a1d31",
    accent: "#c2426f",
    font: "display",
    radius: "round",
    button: "soft",
  },
  mono: {
    label: "Mono",
    background: "#ffffff",
    text: "#111111",
    card: "#111111",
    cardText: "#ffffff",
    accent: "#111111",
    font: "mono",
    radius: "sharp",
    button: "fill",
  },
  forest: {
    label: "Forest",
    background: "linear-gradient(180deg, #12241c 0%, #1d3a2c 100%)",
    text: "#eaf5ee",
    card: "#254736",
    cardText: "#eaf5ee",
    accent: "#7fd6a4",
    font: "serif",
    radius: "soft",
    button: "outline",
  },
  grape: {
    label: "Grape",
    background: "linear-gradient(180deg, #2b1442 0%, #45206b 100%)",
    text: "#f3ebff",
    card: "#582a83",
    cardText: "#f8f3ff",
    accent: "#c79bff",
    font: "display",
    radius: "round",
    button: "fill",
  },
  ocean: {
    label: "Ocean",
    background: "linear-gradient(180deg, #062b45 0%, #0b4a6f 100%)",
    text: "#e8f5ff",
    card: "#0f5f8a",
    cardText: "#eaf6ff",
    accent: "#63c7f5",
    font: "sans",
    radius: "soft",
    button: "fill",
  },
  sand: {
    label: "Sand",
    background: "#efe4d2",
    text: "#3a2e1e",
    card: "#fdf8f1",
    cardText: "#3a2e1e",
    accent: "#a87b3f",
    font: "serif",
    radius: "soft",
    button: "soft",
  },
  berry: {
    label: "Berry",
    background: "linear-gradient(180deg, #3d0a26 0%, #6b1440 100%)",
    text: "#ffeaf3",
    card: "#8d1d55",
    cardText: "#fff0f7",
    accent: "#ff8fbe",
    font: "display",
    radius: "round",
    button: "fill",
  },
  slate: {
    label: "Slate",
    background: "#eceef1",
    text: "#1f242b",
    card: "#ffffff",
    cardText: "#1f242b",
    accent: "#40566f",
    font: "sans",
    radius: "soft",
    button: "outline",
  },
  citrus: {
    label: "Citrus",
    background: "linear-gradient(180deg, #fff3b0 0%, #ffd166 100%)",
    text: "#3c2c05",
    card: "#ffffff",
    cardText: "#3c2c05",
    accent: "#d98324",
    font: "display",
    radius: "round",
    button: "soft",
  },
  noir: {
    label: "Noir",
    background: "#0a0a0a",
    text: "#f2f2f2",
    card: "#0a0a0a",
    cardText: "#f2f2f2",
    accent: "#f2f2f2",
    font: "mono",
    radius: "sharp",
    button: "outline",
  },
  sky: {
    label: "Sky",
    background: "linear-gradient(180deg, #e6f4ff 0%, #c3e4fb 100%)",
    text: "#0d2b3e",
    card: "#ffffff",
    cardText: "#0d2b3e",
    accent: "#1d7fb8",
    font: "sans",
    radius: "round",
    button: "soft",
  },
  clay: {
    label: "Clay",
    background: "linear-gradient(180deg, #8c3d26 0%, #b05b38 100%)",
    text: "#fdece3",
    card: "#f6ddcd",
    cardText: "#5a2414",
    accent: "#ffd2b8",
    font: "serif",
    radius: "soft",
    button: "fill",
  },
  coral: {
    label: "Coral",
    background: "linear-gradient(180deg, #ff7a6b 0%, #ffb3a0 100%)",
    text: "#4a140e",
    card: "#ffffff",
    cardText: "#4a140e",
    accent: "#e04a35",
    font: "sans",
    radius: "round",
    button: "fill",
  },
  lime: {
    label: "Lime",
    background: "linear-gradient(180deg, #dcf77a 0%, #a8de4a 100%)",
    text: "#1f3306",
    card: "#1f3306",
    cardText: "#f3ffd9",
    accent: "#5c8f14",
    font: "display",
    radius: "soft",
    button: "fill",
  },
  steel: {
    label: "Steel",
    background: "#232a31",
    text: "#dfe6ec",
    card: "#313b45",
    cardText: "#dfe6ec",
    accent: "#8fa6bb",
    font: "mono",
    radius: "sharp",
    button: "fill",
  },
  cream: {
    label: "Cream",
    background: "#fbf6ec",
    text: "#4b3a25",
    card: "#4b3a25",
    cardText: "#fbf6ec",
    accent: "#8a6a42",
    font: "serif",
    radius: "round",
    button: "fill",
  },
  violet: {
    label: "Violet",
    background: "linear-gradient(180deg, #f0eaff 0%, #ddd0ff 100%)",
    text: "#2b1a52",
    card: "#5b3ecf",
    cardText: "#f6f2ff",
    accent: "#6d4de0",
    font: "sans",
    radius: "soft",
    button: "fill",
  },
  ember: {
    label: "Ember",
    background: "linear-gradient(180deg, #1a1210 0%, #2c1a14 100%)",
    text: "#ffe6d5",
    card: "#3c231a",
    cardText: "#ffe6d5",
    accent: "#ff8a4c",
    font: "display",
    radius: "soft",
    button: "outline",
  },
  ice: {
    label: "Ice",
    background: "#f4fbfd",
    text: "#123039",
    card: "#ffffff",
    cardText: "#123039",
    accent: "#2f8ca3",
    font: "sans",
    radius: "sharp",
    button: "outline",
  },
  bronze: {
    label: "Bronze",
    background: "linear-gradient(180deg, #221a10 0%, #3b2c17 100%)",
    text: "#f6e6c8",
    card: "#6a5024",
    cardText: "#fff6e3",
    accent: "#d9ab5a",
    font: "serif",
    radius: "round",
    button: "fill",
  },
};

export const DEFAULT_PRESET = "midnight";

/**
 * Colours are validated as hex or as a gradient, not with a general CSS parser: the values
 * end up inside a style attribute, and "anything the browser accepts" there includes
 * `url(...)`. A closed grammar is the cheap way to keep that shut.
 */
const colour = z
  .string()
  .trim()
  .regex(/^#[0-9a-fA-F]{6}$/, "Use a hex colour like #1b2036");

const background = z
  .string()
  .trim()
  .regex(
    /^(#[0-9a-fA-F]{6}|linear-gradient\(\s*\d{1,3}deg\s*(,\s*#[0-9a-fA-F]{6}\s+\d{1,3}%\s*){2,6}\))$/,
    "Use a hex colour or one of the preset gradients",
  );

export const themeSchema = z.object({
  preset: z.string().trim().min(1).max(40).default(DEFAULT_PRESET),
  background: background.optional(),
  text: colour.optional(),
  card: colour.optional(),
  cardText: colour.optional(),
  accent: colour.optional(),
  font: z.enum(Object.keys(FONTS) as [FontKey, ...FontKey[]]).optional(),
  radius: z.enum(Object.keys(RADII) as [RadiusKey, ...RadiusKey[]]).optional(),
  button: z.enum(Object.keys(BUTTON_STYLES) as [ButtonStyle, ...ButtonStyle[]]).optional(),
});

export type Theme = z.infer<typeof themeSchema>;

/** A theme that came out of the database, which may predate any of the fields above. */
export function readTheme(value: unknown): Theme {
  const parsed = themeSchema.safeParse(value);
  return parsed.success ? parsed.data : { preset: DEFAULT_PRESET };
}

export function resolveTheme(theme: Theme): Preset {
  const base = PRESETS[theme.preset] ?? PRESETS[DEFAULT_PRESET];
  return {
    ...base,
    background: theme.background ?? base.background,
    text: theme.text ?? base.text,
    card: theme.card ?? base.card,
    cardText: theme.cardText ?? base.cardText,
    accent: theme.accent ?? base.accent,
    font: theme.font ?? base.font,
    radius: theme.radius ?? base.radius,
    button: theme.button ?? base.button,
  };
}

/**
 * The resolved theme as custom properties, so the page and the editor's preview render from
 * the same values and cannot drift apart.
 */
export function themeStyle(theme: Theme): CSSProperties {
  const t = resolveTheme(theme);
  return {
    "--page-bg": t.background,
    "--page-fg": t.text,
    "--card-bg": t.card,
    "--card-fg": t.cardText,
    "--accent": t.accent,
    "--card-radius": RADII[t.radius].value,
    "--page-font": FONTS[t.font].stack,
  } as CSSProperties;
}

/** Card styling per button style, kept here so both the page and the preview agree. */
export function cardStyle(theme: Theme): CSSProperties {
  const t = resolveTheme(theme);
  const shared: CSSProperties = {
    borderRadius: "var(--card-radius)",
    fontFamily: "var(--page-font)",
  };

  if (t.button === "outline") {
    return {
      ...shared,
      background: "transparent",
      color: "var(--page-fg)",
      border: "1.5px solid var(--page-fg)",
    };
  }
  if (t.button === "soft") {
    return {
      ...shared,
      background: "var(--card-bg)",
      color: "var(--card-fg)",
      border: "1px solid transparent",
      boxShadow: "0 6px 18px -12px rgba(0, 0, 0, 0.55)",
    };
  }
  return {
    ...shared,
    background: "var(--card-bg)",
    color: "var(--card-fg)",
    border: "1px solid transparent",
  };
}
