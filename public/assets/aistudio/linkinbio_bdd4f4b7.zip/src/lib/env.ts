/**
 * Reads the environment variables every Supabase client needs.
 *
 * Without this a missing variable surfaced as a vague failure from inside the Supabase SDK,
 * or as `undefined` appended to a request URL. On a hosted build the usual cause is simply
 * forgetting to add the variable in the project settings, so the message says exactly that.
 */
function required(name: string, value: string | undefined): string {
  if (!value) {
    throw new Error(
      `${name} is not set. Add it to .env.local for local development, or to the ` +
        `project's environment variables on the host, then redeploy.`,
    );
  }
  return value;
}

export function supabaseUrl(): string {
  return required("NEXT_PUBLIC_SUPABASE_URL", process.env.NEXT_PUBLIC_SUPABASE_URL);
}

export function supabaseAnonKey(): string {
  return required("NEXT_PUBLIC_SUPABASE_ANON_KEY", process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
}

export function supabaseServiceRoleKey(): string {
  return required("SUPABASE_SERVICE_ROLE_KEY", process.env.SUPABASE_SERVICE_ROLE_KEY);
}

/**
 * The deployed origin, used for auth callbacks and for the link a creator shares.
 *
 * Every fallback here is a truthiness check, not `??`. A variable declared with an empty
 * value is not undefined, so `??` accepts the blank string — which then reaches
 * `new URL("")` and fails the build with nothing but "Invalid URL" to go on.
 */
export function siteUrl(): string {
  const explicit = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  if (explicit) return explicit.replace(/\/+$/, "");

  const vercel = process.env.VERCEL_URL?.trim();
  if (vercel) return `https://${vercel.replace(/^https?:\/\//, "")}`;

  return "http://localhost:3000";
}
