import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import { supabaseAnonKey, supabaseUrl } from "@/lib/env";

/**
 * The app's own pages, as opposed to the whole rest of the URL space, which belongs to
 * creator handles.
 *
 * This is an allow-list of what needs a session, not a block-list of what does not. On this
 * product the root namespace is public -- `/someone` is somebody's page -- so a guard that
 * defaults to "signed in only" would put a login wall in front of every creator page.
 */
const PROTECTED_PREFIXES = ["/editor", "/appearance", "/analytics", "/settings", "/onboarding"];

/** Refreshes the auth cookie on every request, and keeps the editor signed-in only. */
export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({ request });

  const supabase = createServerClient(supabaseUrl(), supabaseAnonKey(), {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
        response = NextResponse.next({ request });
        cookiesToSet.forEach(({ name, value, options }) =>
          response.cookies.set(name, value, options),
        );
      },
    },
  });

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { pathname } = request.nextUrl;
  const needsUser = PROTECTED_PREFIXES.some(
    (prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`),
  );

  if (!user && needsUser) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.search = "";
    url.searchParams.set("next", pathname);
    return NextResponse.redirect(url);
  }

  if (user && (pathname === "/login" || pathname === "/signup")) {
    const url = request.nextUrl.clone();
    url.pathname = "/editor";
    url.search = "";
    return NextResponse.redirect(url);
  }

  return response;
}
