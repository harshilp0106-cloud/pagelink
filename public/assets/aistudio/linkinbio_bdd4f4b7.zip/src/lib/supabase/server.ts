import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import { supabaseAnonKey, supabaseUrl } from "@/lib/env";

/**
 * Server-side client bound to the request's cookies, so row level security sees the
 * signed-in creator. A server component cannot write cookies, which is why setAll swallows
 * the attempt — refreshing the session is the proxy's job.
 */
export async function createClient() {
  const store = await cookies();

  return createServerClient(supabaseUrl(), supabaseAnonKey(), {
    cookies: {
      getAll() {
        return store.getAll();
      },
      setAll(cookiesToSet) {
        try {
          cookiesToSet.forEach(({ name, value, options }) => store.set(name, value, options));
        } catch {
          // Called from a server component; the proxy already refreshed the session.
        }
      },
    },
  });
}
