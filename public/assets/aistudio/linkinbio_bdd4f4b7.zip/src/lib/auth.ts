import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { readTheme } from "@/lib/theme";
import type { Profile } from "@/lib/types";

/**
 * The signed-in user, or null. Uses getUser rather than getSession, because a session read
 * from a cookie is only as trustworthy as the cookie; getUser verifies it with Supabase.
 */
export async function currentUser() {
  const supabase = await createClient();
  const { data } = await supabase.auth.getUser();
  return data.user ?? null;
}

export async function requireUser() {
  const user = await currentUser();
  if (!user) redirect("/login");
  return user;
}

/**
 * The signed-in creator's profile.
 *
 * Signing in with Google skips the form that claims a handle, so a verified user with no
 * profile row is a normal state and not an error -- they go and pick a handle.
 */
export async function requireProfile(): Promise<Profile> {
  const user = await requireUser();
  const supabase = await createClient();

  const { data } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .maybeSingle();

  if (!data) redirect("/onboarding");

  return { ...data, theme: readTheme(data.theme) } as Profile;
}
