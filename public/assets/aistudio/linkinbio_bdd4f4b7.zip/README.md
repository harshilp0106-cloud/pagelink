# Link in Bio

A link-in-bio product for creators, in the style of lnk.bio. Separate product from
PitchBrand, same client.

Agreed with the client on 2026-09-09: **$800, 30 days.** Billing and subscriptions are
deliberately out of this order — the client asked for the product first and said billing
comes later.

## Stack

Same as PitchBrand, so nothing new has to be learned or paid for.

| | | |
|---|---|---|
| Next.js 16 (App Router), TypeScript | UI + API | One deployable, no separate backend |
| Tailwind 4 | styling | Tokens in `src/app/globals.css` |
| Supabase | Postgres, Auth, Storage | Free tier covers all three |
| Vercel | hosting | Free Hobby tier |

## Setting it up

1. Create a Supabase project.
2. Put the URL, the anon key and the service role key from **Project settings → API** into
   `.env.local`, replacing the placeholders. That file is committed in this repo on
   purpose, because the repo is private.
3. Run the migrations in `supabase/migrations/` in order, in the SQL editor.
4. Under **Authentication → URL configuration**, set the site URL and add
   `<origin>/auth/callback` as a redirect URL — once for `http://localhost:3000`, and
   again for the deployed origin later.
5. For Google sign-in, enable the Google provider under **Authentication → Providers** and
   paste in a Google OAuth client id and secret.
6. `npm install && npm run dev`.

Migration `0001` creates the `avatars` storage bucket and its policies, so nothing needs
setting up by hand in the Storage dashboard.

## How it fits together

```
src/app
  page.tsx              landing page, redirects a signed-in creator to the editor
  [handle]/             the public page, at /@handle
  r/[id]/               click counter and redirect
  (auth)/               sign in, sign up, password reset
  auth/callback/        exchanges every emailed or OAuth code for a session
  onboarding/           claiming a handle (Google sign-in arrives without one)
  (app)/                the editor, behind the session guard
    editor/             links, section titles, embeds, ordering
    appearance/         photo, name, bio, social icons, theme
    analytics/          views and clicks over a date range
    settings/           publishing, handle, password, account deletion
src/lib
  links.ts              reads a pasted URL: platform, embeddable id, icon
  theme.ts              the eight presets, the theme schema, and the CSS it resolves to
src/proxy.ts            session refresh, and the guard on the editor
```

Two things are worth knowing before changing anything:

- **The public page and the editor's preview are the same component**
  (`src/components/creator-page.tsx`), rendered from the same props. A preview built from
  separate markup eventually lies about what the page looks like.
- **The root of the URL space belongs to creators.** `/@karan` is a page, so the session
  guard is an allow-list of the app's own routes rather than a block-list. A new app route
  needs adding to `PROTECTED_PREFIXES` in `src/lib/supabase/session.ts` **and** to
  `reserved_handles`, or a creator could claim a handle that shadows it.

## Scope for this order

- [x] Creator signup and login, with Google as well as email and password
- [x] Public page on the creator's own handle, mobile first
- [x] Links: add, edit, reorder, show or hide, with icons
- [x] Social icons row
- [x] Embeds for YouTube, Instagram and Spotify
- [x] Profile photo, name and bio
- [x] Theme presets with colour and font choices
- [x] Editor with live preview
- [x] Analytics: page views, clicks per link, over a date range
- [ ] Deployed to a live URL, code handed over

Not in this order: subscriptions and billing, custom domains, email capture.

Instagram posts show as a card that opens the post rather than an inline embed: Instagram's
own embed script runs client-side and fails often enough to leave a hole in the page, and
fetching a thumbnail through oEmbed now needs a Facebook app and token.
